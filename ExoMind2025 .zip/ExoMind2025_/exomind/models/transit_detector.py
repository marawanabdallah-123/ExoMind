"""
Transit Detector Model
======================

Main model class for exoplanet transit detection, adapted from AstroNet's 
SourceSegmentation class but designed for 1D time series data.
"""

import tensorflow as tf
from tensorflow.keras import Model
from tensorflow.keras.layers import Input, Dense, Dropout, GlobalAveragePooling1D
from typing import Optional, Dict, Any
import numpy as np

from .transit_cnn import TransitCNN
from .transit_lstm import TransitLSTM


class TransitDetector(tf.keras.Model):
    """
    Main transit detection model class.
    
    Adapts AstroNet's SourceSegmentation infrastructure for 1D time series
    transit detection instead of 2D image segmentation.
    """
    
    def __init__(self, 
                 input_shape: tuple,
                 model_type: str = 'cnn',
                 num_classes: int = 2,
                 use_class_weights: bool = True,
                 dropout_rate: float = 0.3,
                 **kwargs):
        """
        Initialize transit detector.
        
        Args:
            input_shape: Input shape (sequence_length, 1)
            model_type: Type of model ('cnn', 'lstm', 'hybrid')
            num_classes: Number of output classes (2 for binary classification)
            use_class_weights: Whether to use class weights
            dropout_rate: Dropout rate for regularization
        """
        super().__init__(name='TransitDetector')
        
        self.input_shape = input_shape
        self.model_type = model_type
        self.num_classes = num_classes
        self.use_class_weights = use_class_weights
        self.dropout_rate = dropout_rate
        
        # Create backbone model
        if model_type == 'cnn':
            self.backbone = TransitCNN(input_shape, **kwargs)
        elif model_type == 'lstm':
            self.backbone = TransitLSTM(input_shape, **kwargs)
        elif model_type == 'hybrid':
            # Hybrid CNN-LSTM model
            self.backbone = self._create_hybrid_model(input_shape, **kwargs)
        else:
            raise ValueError(f"Unknown model type: {model_type}")
        
        # Classification head
        self.global_pool = GlobalAveragePooling1D()
        self.dropout = Dropout(dropout_rate)
        self.classifier = Dense(num_classes, activation='softmax', name='classifier')
        
        # Build model
        self.build(input_shape)
    
    def _create_hybrid_model(self, input_shape: tuple, **kwargs) -> Model:
        """Create hybrid CNN-LSTM model."""
        inputs = Input(shape=input_shape, name='input')
        
        # CNN feature extraction
        cnn_model = TransitCNN(input_shape, **kwargs)
        cnn_features = cnn_model.backbone(inputs)
        
        # LSTM processing
        lstm_model = TransitLSTM(input_shape, **kwargs)
        lstm_features = lstm_model.backbone(cnn_features)
        
        # Combine features
        combined = tf.keras.layers.Concatenate()([cnn_features, lstm_features])
        
        return Model(inputs=inputs, outputs=combined, name='hybrid_backbone')
    
    def build(self, input_shape):
        """Build the model."""
        inputs = Input(shape=input_shape, name='input')
        x = self.backbone(inputs)
        x = self.global_pool(x)
        x = self.dropout(x)
        outputs = self.classifier(x)
        
        self.model = Model(inputs=inputs, outputs=outputs, name='TransitDetector')
    
    def call(self, x, training=False):
        """Forward pass."""
        return self.model(x, training)
    
    def train_step(self, data):
        """
        Custom training step with class weights support.
        
        Adapted from AstroNet's train_step method.
        """
        if isinstance(data, dict):
            x = data['flux']
            y = data['label']
            sample_weights = data.get('class_weight', None)
        else:
            x, y = data
            sample_weights = None
        
        if not self.use_class_weights:
            sample_weights = None
        
        with tf.GradientTape() as tape:
            y_pred = self(x, training=True)
            loss = self.compiled_loss(y, y_pred, sample_weight=sample_weights, 
                                    regularization_losses=self.losses)
        
        # Compute gradients
        trainable_vars = self.trainable_variables
        gradients = tape.gradient(loss, trainable_vars)
        
        # Update weights
        self.optimizer.apply_gradients(zip(gradients, trainable_vars))
        
        # Update metrics
        self.compiled_metrics.update_state(y, y_pred, sample_weight=sample_weights)
        
        metrics = {m.name: m.result() for m in self.metrics}
        return metrics
    
    def test_step(self, data):
        """
        Custom test step with class weights support.
        
        Adapted from AstroNet's test_step method.
        """
        if isinstance(data, dict):
            x = data['flux']
            y = data['label']
            sample_weights = data.get('class_weight', None)
        else:
            x, y = data
            sample_weights = None
        
        if not self.use_class_weights:
            sample_weights = None
        
        y_pred = self(x, training=False)
        self.compiled_loss(y, y_pred, sample_weight=sample_weights, 
                          regularization_losses=self.losses)
        self.compiled_metrics.update_state(y, y_pred, sample_weight=sample_weights)
        
        metrics = {m.name: m.result() for m in self.metrics}
        return metrics
    
    def predict_transit_probability(self, flux_data: np.ndarray) -> float:
        """
        Predict transit probability for a single lightcurve.
        
        Args:
            flux_data: 1D array of flux values
            
        Returns:
            Probability of transit detection
        """
        # Ensure correct shape
        if flux_data.ndim == 1:
            flux_data = np.expand_dims(flux_data, axis=-1)
        
        if flux_data.ndim == 2:
            flux_data = np.expand_dims(flux_data, axis=0)
        
        # Predict
        prediction = self.predict(flux_data, verbose=0)
        
        # Return probability of positive class (transit)
        return float(prediction[0][1])
    
    def detect_transits(self, flux_data: np.ndarray, threshold: float = 0.5) -> Dict:
        """
        Detect transits in a lightcurve with confidence score.
        
        Args:
            flux_data: 1D array of flux values
            threshold: Classification threshold
            
        Returns:
            Dictionary with detection results
        """
        prob = self.predict_transit_probability(flux_data)
        
        return {
            'has_transit': prob > threshold,
            'confidence': prob,
            'threshold': threshold
        }
    
    def get_model_summary(self) -> str:
        """Get model summary as string."""
        return self.model.summary()


