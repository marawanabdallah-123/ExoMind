"""
Transit CNN Model
=================

1D CNN architecture for exoplanet transit detection in time series data.
"""

import tensorflow as tf
from tensorflow.keras import Model
from tensorflow.keras.layers import (
    Input, Conv1D, MaxPooling1D, BatchNormalization, 
    Dropout, Dense, GlobalAveragePooling1D
)


class TransitCNN(Model):
    """
    1D CNN for transit detection.
    
    Architecture inspired by successful time series classification models
    but adapted for exoplanet transit detection.
    """
    
    def __init__(self, input_shape: tuple, num_filters: int = 64, 
                 kernel_size: int = 3, dropout_rate: float = 0.3, **kwargs):
        """
        Initialize Transit CNN.
        
        Args:
            input_shape: Input shape (sequence_length, 1)
            num_filters: Number of filters in first conv layer
            kernel_size: Kernel size for convolutions
            dropout_rate: Dropout rate
        """
        super().__init__(name='TransitCNN')
        
        self.input_shape = input_shape
        self.num_filters = num_filters
        self.kernel_size = kernel_size
        self.dropout_rate = dropout_rate
        
        # Build the backbone
        self.backbone = self._build_backbone()
        
        # Build full model
        self.build(input_shape)
    
    def _build_backbone(self) -> Model:
        """Build the CNN backbone."""
        inputs = Input(shape=self.input_shape, name='input')
        
        # Block 1
        x = Conv1D(self.num_filters, self.kernel_size, activation='relu', padding='same')(inputs)
        x = BatchNormalization()(x)
        x = Conv1D(self.num_filters, self.kernel_size, activation='relu', padding='same')(x)
        x = BatchNormalization()(x)
        x = MaxPooling1D(2)(x)
        x = Dropout(self.dropout_rate)(x)
        
        # Block 2
        x = Conv1D(self.num_filters * 2, self.kernel_size, activation='relu', padding='same')(x)
        x = BatchNormalization()(x)
        x = Conv1D(self.num_filters * 2, self.kernel_size, activation='relu', padding='same')(x)
        x = BatchNormalization()(x)
        x = MaxPooling1D(2)(x)
        x = Dropout(self.dropout_rate)(x)
        
        # Block 3
        x = Conv1D(self.num_filters * 4, self.kernel_size, activation='relu', padding='same')(x)
        x = BatchNormalization()(x)
        x = Conv1D(self.num_filters * 4, self.kernel_size, activation='relu', padding='same')(x)
        x = BatchNormalization()(x)
        x = MaxPooling1D(2)(x)
        x = Dropout(self.dropout_rate)(x)
        
        # Block 4
        x = Conv1D(self.num_filters * 8, self.kernel_size, activation='relu', padding='same')(x)
        x = BatchNormalization()(x)
        x = Conv1D(self.num_filters * 8, self.kernel_size, activation='relu', padding='same')(x)
        x = BatchNormalization()(x)
        x = MaxPooling1D(2)(x)
        x = Dropout(self.dropout_rate)(x)
        
        # Global average pooling
        x = GlobalAveragePooling1D()(x)
        
        return Model(inputs=inputs, outputs=x, name='cnn_backbone')
    
    def call(self, x, training=False):
        """Forward pass."""
        return self.backbone(x, training)
    
    def build(self, input_shape):
        """Build the model."""
        self.backbone.build(input_shape)


