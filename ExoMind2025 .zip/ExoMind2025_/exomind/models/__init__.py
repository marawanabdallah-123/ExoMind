"""
ExoMind Models Module
=====================

This module provides neural network architectures for exoplanet transit detection.
Adapted from AstroNet's infrastructure but designed for 1D time series data.
"""

from .transit_detector import TransitDetector
from .transit_cnn import TransitCNN
from .transit_lstm import TransitLSTM

__all__ = ['TransitDetector', 'TransitCNN', 'TransitLSTM']


