"""
Transit LSTM Model
==================

LSTM architecture for exoplanet transit detection in time series data.
"""

import tensorflow as tf
from tensorflow.keras import Model
from tensorflow.keras.layers import (
    Input, LSTM, Bidirectional, Dropout, Dense, 
    BatchNormalization, GlobalAveragePooling1D
)


class TransitLSTM(Model):
    """
    LSTM model for transit detection.
    
    Uses bidirectional LSTM layers to capture temporal patterns
    in lightcurve data.
    """
    
    def __init__(self, input_shape: tuple, lstm_units: int = 128, 
                 dropout_rate: float = 0.3, **kwargs):
        """
        Initialize Transit LSTM.
        
        Args:
            input_shape: Input shape (sequence_length, 1)
            lstm_units: Number of LSTM units
            dropout_rate: Dropout rate
        """
        super().__init__(name='TransitLSTM')
        
        self.input_shape = input_shape
        self.lstm_units = lstm_units
        self.dropout_rate = dropout_rate
        
        # Build the backbone
        self.backbone = self._build_backbone()
        
        # Build full model
        self.build(input_shape)
    
    def _build_backbone(self) -> Model:
        """Build the LSTM backbone."""
        inputs = Input(shape=self.input_shape, name='input')
        
        # Reshape for LSTM (remove channel dimension)
        x = tf.keras.layers.Lambda(lambda x: tf.squeeze(x, axis=-1))(inputs)
        
        # First LSTM layer
        x = Bidirectional(LSTM(self.lstm_units, return_sequences=True))(x)
        x = BatchNormalization()(x)
        x = Dropout(self.dropout_rate)(x)
        
        # Second LSTM layer
        x = Bidirectional(LSTM(self.lstm_units // 2, return_sequences=True))(x)
        x = BatchNormalization()(x)
        x = Dropout(self.dropout_rate)(x)
        
        # Third LSTM layer
        x = Bidirectional(LSTM(self.lstm_units // 4, return_sequences=True))(x)
        x = BatchNormalization()(x)
        x = Dropout(self.dropout_rate)(x)
        
        # Global average pooling
        x = GlobalAveragePooling1D()(x)
        
        return Model(inputs=inputs, outputs=x, name='lstm_backbone')
    
    def call(self, x, training=False):
        """Forward pass."""
        return self.backbone(x, training)
    
    def build(self, input_shape):
        """Build the model."""
        self.backbone.build(input_shape)


