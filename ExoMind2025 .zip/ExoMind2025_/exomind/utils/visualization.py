"""
Visualization Utilities
========================

Utility functions for visualizing lightcurve data and transit detection results.
"""

import matplotlib.pyplot as plt
import numpy as np
from typing import Optional, Dict, List, Tuple
import matplotlib.patches as patches


def plot_lightcurve(time: np.ndarray, flux: np.ndarray, 
                   title: str = "Lightcurve", 
                   ylabel: str = "Normalized Flux",
                   xlabel: str = "Time (days)",
                   figsize: Tuple[int, int] = (12, 6),
                   quality: Optional[np.ndarray] = None,
                   highlight_transits: bool = False,
                   transit_times: Optional[List[float]] = None,
                   transit_durations: Optional[List[float]] = None) -> plt.Figure:
    """
    Plot a lightcurve with optional transit highlighting.
    
    Args:
        time: Time array
        flux: Flux array
        title: Plot title
        ylabel: Y-axis label
        xlabel: X-axis label
        figsize: Figure size
        quality: Quality flags array
        highlight_transits: Whether to highlight transits
        transit_times: List of transit center times
        transit_durations: List of transit durations
        
    Returns:
        Matplotlib figure
    """
    fig, ax = plt.subplots(figsize=figsize)
    
    # Plot flux
    if quality is not None:
        # Plot good quality data
        good_mask = quality == 0
        bad_mask = quality != 0
        
        ax.plot(time[good_mask], flux[good_mask], 'b-', alpha=0.7, label='Good data')
        if np.any(bad_mask):
            ax.plot(time[bad_mask], flux[bad_mask], 'r.', alpha=0.5, label='Bad data')
    else:
        ax.plot(time, flux, 'b-', alpha=0.7)
    
    # Highlight transits
    if highlight_transits and transit_times is not None:
        for i, (t0, duration) in enumerate(zip(transit_times, transit_durations or [0.5] * len(transit_times))):
            # Create rectangle for transit
            rect = patches.Rectangle((t0 - duration/2, np.min(flux)), 
                                   duration, np.max(flux) - np.min(flux),
                                   linewidth=1, edgecolor='red', 
                                   facecolor='red', alpha=0.2)
            ax.add_patch(rect)
    
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(True, alpha=0.3)
    
    if quality is not None:
        ax.legend()
    
    plt.tight_layout()
    return fig


def plot_transit_detection(time: np.ndarray, flux: np.ndarray, 
                          y_pred: np.ndarray, y_prob: Optional[np.ndarray] = None,
                          y_true: Optional[np.ndarray] = None,
                          threshold: float = 0.5,
                          title: str = "Transit Detection Results",
                          figsize: Tuple[int, int] = (15, 10)) -> plt.Figure:
    """
    Plot transit detection results.
    
    Args:
        time: Time array
        flux: Flux array
        y_pred: Predicted labels
        y_prob: Predicted probabilities (optional)
        y_true: True labels (optional)
        threshold: Classification threshold
        title: Plot title
        figsize: Figure size
        
    Returns:
        Matplotlib figure
    """
    n_plots = 2 if y_prob is not None else 1
    if y_true is not None:
        n_plots += 1
    
    fig, axes = plt.subplots(n_plots, 1, figsize=figsize, sharex=True)
    
    if n_plots == 1:
        axes = [axes]
    
    # Plot 1: Lightcurve with predictions
    ax1 = axes[0]
    ax1.plot(time, flux, 'b-', alpha=0.7, label='Flux')
    
    # Highlight predicted transits
    transit_mask = y_pred == 1
    if np.any(transit_mask):
        ax1.scatter(time[transit_mask], flux[transit_mask], 
                   c='red', s=20, alpha=0.8, label='Predicted Transits')
    
    # Highlight true transits if available
    if y_true is not None:
        true_transit_mask = y_true == 1
        if np.any(true_transit_mask):
            ax1.scatter(time[true_transit_mask], flux[true_transit_mask], 
                       c='green', s=30, alpha=0.6, marker='s', 
                       label='True Transits')
    
    ax1.set_ylabel('Normalized Flux')
    ax1.set_title(title)
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # Plot 2: Probabilities (if available)
    if y_prob is not None:
        ax2 = axes[1]
        ax2.plot(time, y_prob, 'g-', alpha=0.7, label='Transit Probability')
        ax2.axhline(y=threshold, color='red', linestyle='--', 
                   alpha=0.8, label=f'Threshold ({threshold})')
        
        # Highlight predicted transits
        if np.any(transit_mask):
            ax2.scatter(time[transit_mask], y_prob[transit_mask], 
                       c='red', s=20, alpha=0.8)
        
        ax2.set_ylabel('Probability')
        ax2.set_ylim(0, 1)
        ax2.legend()
        ax2.grid(True, alpha=0.3)
    
    # Plot 3: True vs Predicted comparison (if available)
    if y_true is not None:
        ax3 = axes[-1]
        ax3.plot(time, y_true, 'g-', alpha=0.7, label='True Labels')
        ax3.plot(time, y_pred, 'r--', alpha=0.7, label='Predicted Labels')
        ax3.set_ylabel('Labels')
        ax3.set_xlabel('Time (days)')
        ax3.set_ylim(-0.1, 1.1)
        ax3.legend()
        ax3.grid(True, alpha=0.3)
    else:
        axes[-1].set_xlabel('Time (days)')
    
    plt.tight_layout()
    return fig


def plot_training_history(history: Dict, figsize: Tuple[int, int] = (15, 5)) -> plt.Figure:
    """
    Plot training history.
    
    Args:
        history: Training history dictionary
        figsize: Figure size
        
    Returns:
        Matplotlib figure
    """
    fig, axes = plt.subplots(1, 3, figsize=figsize)
    
    # Loss
    axes[0].plot(history['loss'], label='Training Loss')
    if 'val_loss' in history:
        axes[0].plot(history['val_loss'], label='Validation Loss')
    axes[0].set_title('Model Loss')
    axes[0].set_xlabel('Epoch')
    axes[0].set_ylabel('Loss')
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)
    
    # Accuracy
    axes[1].plot(history['accuracy'], label='Training Accuracy')
    if 'val_accuracy' in history:
        axes[1].plot(history['val_accuracy'], label='Validation Accuracy')
    axes[1].set_title('Model Accuracy')
    axes[1].set_xlabel('Epoch')
    axes[1].set_ylabel('Accuracy')
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)
    
    # Precision/Recall
    if 'precision' in history:
        axes[2].plot(history['precision'], label='Precision')
    if 'recall' in history:
        axes[2].plot(history['recall'], label='Recall')
    if 'val_precision' in history:
        axes[2].plot(history['val_precision'], label='Val Precision')
    if 'val_recall' in history:
        axes[2].plot(history['val_recall'], label='Val Recall')
    axes[2].set_title('Precision & Recall')
    axes[2].set_xlabel('Epoch')
    axes[2].set_ylabel('Score')
    axes[2].legend()
    axes[2].grid(True, alpha=0.3)
    
    plt.tight_layout()
    return fig


def plot_confusion_matrix(y_true: np.ndarray, y_pred: np.ndarray, 
                         figsize: Tuple[int, int] = (8, 6)) -> plt.Figure:
    """
    Plot confusion matrix.
    
    Args:
        y_true: True labels
        y_pred: Predicted labels
        figsize: Figure size
        
    Returns:
        Matplotlib figure
    """
    from sklearn.metrics import confusion_matrix
    import seaborn as sns
    
    cm = confusion_matrix(y_true, y_pred)
    
    fig, ax = plt.subplots(figsize=figsize)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
                xticklabels=['No Transit', 'Transit'],
                yticklabels=['No Transit', 'Transit'])
    
    ax.set_title('Confusion Matrix')
    ax.set_xlabel('Predicted')
    ax.set_ylabel('Actual')
    
    plt.tight_layout()
    return fig


def plot_roc_curve(y_true: np.ndarray, y_prob: np.ndarray, 
                  figsize: Tuple[int, int] = (8, 6)) -> plt.Figure:
    """
    Plot ROC curve.
    
    Args:
        y_true: True labels
        y_prob: Predicted probabilities
        figsize: Figure size
        
    Returns:
        Matplotlib figure
    """
    from sklearn.metrics import roc_curve, auc
    
    fpr, tpr, _ = roc_curve(y_true, y_prob)
    roc_auc = auc(fpr, tpr)
    
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(fpr, tpr, color='darkorange', lw=2, 
           label=f'ROC curve (AUC = {roc_auc:.2f})')
    ax.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    ax.set_xlim([0.0, 1.0])
    ax.set_ylim([0.0, 1.05])
    ax.set_xlabel('False Positive Rate')
    ax.set_ylabel('True Positive Rate')
    ax.set_title('Receiver Operating Characteristic (ROC) Curve')
    ax.legend(loc="lower right")
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    return fig


