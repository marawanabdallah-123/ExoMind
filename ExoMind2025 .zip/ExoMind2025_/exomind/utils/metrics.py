"""
Metrics Utilities
==================

Utility functions for evaluating transit detection performance.
"""

import numpy as np
from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score
from typing import Dict, List, Tuple, Optional


def compute_transit_metrics(y_true: np.ndarray, y_pred: np.ndarray, 
                          y_prob: Optional[np.ndarray] = None) -> Dict:
    """
    Compute comprehensive metrics for transit detection.
    
    Args:
        y_true: True labels (0 or 1)
        y_pred: Predicted labels (0 or 1)
        y_prob: Predicted probabilities (optional)
        
    Returns:
        Dictionary of metrics
    """
    metrics = {}
    
    # Basic classification metrics
    metrics['accuracy'] = np.mean(y_true == y_pred)
    metrics['precision'] = precision_score(y_true, y_pred, zero_division=0)
    metrics['recall'] = recall_score(y_true, y_pred, zero_division=0)
    metrics['f1_score'] = f1_score(y_true, y_pred, zero_division=0)
    
    # ROC AUC if probabilities are provided
    if y_prob is not None:
        try:
            metrics['roc_auc'] = roc_auc_score(y_true, y_prob)
        except ValueError:
            metrics['roc_auc'] = 0.5  # Default for single class
    
    # Class-specific metrics
    n_transits_true = np.sum(y_true)
    n_transits_pred = np.sum(y_pred)
    
    metrics['true_transits'] = int(n_transits_true)
    metrics['predicted_transits'] = int(n_transits_pred)
    
    # Transit detection rate
    if n_transits_true > 0:
        metrics['transit_detection_rate'] = np.sum((y_true == 1) & (y_pred == 1)) / n_transits_true
    else:
        metrics['transit_detection_rate'] = 0.0
    
    # False positive rate
    n_no_transit_true = np.sum(y_true == 0)
    if n_no_transit_true > 0:
        metrics['false_positive_rate'] = np.sum((y_true == 0) & (y_pred == 1)) / n_no_transit_true
    else:
        metrics['false_positive_rate'] = 0.0
    
    return metrics


def calculate_precision_recall(y_true: np.ndarray, y_prob: np.ndarray, 
                             thresholds: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Calculate precision-recall curve.
    
    Args:
        y_true: True labels
        y_prob: Predicted probabilities
        thresholds: Threshold values (optional)
        
    Returns:
        Tuple of (precision, recall, thresholds)
    """
    if thresholds is None:
        thresholds = np.linspace(0, 1, 101)
    
    precision = np.zeros_like(thresholds)
    recall = np.zeros_like(thresholds)
    
    for i, threshold in enumerate(thresholds):
        y_pred = (y_prob >= threshold).astype(int)
        
        if np.sum(y_pred) > 0:
            precision[i] = precision_score(y_true, y_pred, zero_division=0)
        else:
            precision[i] = 0.0
        
        if np.sum(y_true) > 0:
            recall[i] = recall_score(y_true, y_pred, zero_division=0)
        else:
            recall[i] = 0.0
    
    return precision, recall, thresholds


def calculate_optimal_threshold(y_true: np.ndarray, y_prob: np.ndarray, 
                              metric: str = 'f1') -> float:
    """
    Calculate optimal classification threshold.
    
    Args:
        y_true: True labels
        y_prob: Predicted probabilities
        metric: Metric to optimize ('f1', 'precision', 'recall', 'accuracy')
        
    Returns:
        Optimal threshold value
    """
    thresholds = np.linspace(0, 1, 101)
    scores = np.zeros_like(thresholds)
    
    for i, threshold in enumerate(thresholds):
        y_pred = (y_prob >= threshold).astype(int)
        
        if metric == 'f1':
            scores[i] = f1_score(y_true, y_pred, zero_division=0)
        elif metric == 'precision':
            scores[i] = precision_score(y_true, y_pred, zero_division=0)
        elif metric == 'recall':
            scores[i] = recall_score(y_true, y_pred, zero_division=0)
        elif metric == 'accuracy':
            scores[i] = np.mean(y_true == y_pred)
        else:
            raise ValueError(f"Unknown metric: {metric}")
    
    optimal_idx = np.argmax(scores)
    return thresholds[optimal_idx]


def compute_confusion_matrix_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict:
    """
    Compute detailed confusion matrix metrics.
    
    Args:
        y_true: True labels
        y_pred: Predicted labels
        
    Returns:
        Dictionary with confusion matrix metrics
    """
    tp = np.sum((y_true == 1) & (y_pred == 1))  # True positives
    tn = np.sum((y_true == 0) & (y_pred == 0))  # True negatives
    fp = np.sum((y_true == 0) & (y_pred == 1))  # False positives
    fn = np.sum((y_true == 1) & (y_pred == 0))  # False negatives
    
    metrics = {
        'true_positives': int(tp),
        'true_negatives': int(tn),
        'false_positives': int(fp),
        'false_negatives': int(fn)
    }
    
    # Additional derived metrics
    if tp + fn > 0:
        metrics['sensitivity'] = tp / (tp + fn)  # Recall/True Positive Rate
    else:
        metrics['sensitivity'] = 0.0
    
    if tn + fp > 0:
        metrics['specificity'] = tn / (tn + fp)  # True Negative Rate
    else:
        metrics['specificity'] = 0.0
    
    if tp + fp > 0:
        metrics['positive_predictive_value'] = tp / (tp + fp)  # Precision
    else:
        metrics['positive_predictive_value'] = 0.0
    
    if tn + fn > 0:
        metrics['negative_predictive_value'] = tn / (tn + fn)
    else:
        metrics['negative_predictive_value'] = 0.0
    
    return metrics


def evaluate_model_performance(y_true: np.ndarray, y_pred: np.ndarray, 
                             y_prob: Optional[np.ndarray] = None) -> Dict:
    """
    Comprehensive model evaluation.
    
    Args:
        y_true: True labels
        y_pred: Predicted labels
        y_prob: Predicted probabilities
        
    Returns:
        Comprehensive metrics dictionary
    """
    # Basic metrics
    basic_metrics = compute_transit_metrics(y_true, y_pred, y_prob)
    
    # Confusion matrix metrics
    confusion_metrics = compute_confusion_matrix_metrics(y_true, y_pred)
    
    # Combine all metrics
    all_metrics = {**basic_metrics, **confusion_metrics}
    
    # Add optimal threshold if probabilities are provided
    if y_prob is not None:
        all_metrics['optimal_threshold_f1'] = calculate_optimal_threshold(y_true, y_prob, 'f1')
        all_metrics['optimal_threshold_precision'] = calculate_optimal_threshold(y_true, y_prob, 'precision')
        all_metrics['optimal_threshold_recall'] = calculate_optimal_threshold(y_true, y_prob, 'recall')
    
    return all_metrics


def compute_class_balance_metrics(y_true: np.ndarray) -> Dict:
    """
    Compute class balance metrics.
    
    Args:
        y_true: True labels
        
    Returns:
        Dictionary with class balance information
    """
    total_samples = len(y_true)
    positive_samples = np.sum(y_true)
    negative_samples = total_samples - positive_samples
    
    return {
        'total_samples': total_samples,
        'positive_samples': int(positive_samples),
        'negative_samples': int(negative_samples),
        'positive_ratio': positive_samples / total_samples,
        'negative_ratio': negative_samples / total_samples,
        'class_balance_ratio': positive_samples / (negative_samples + 1e-8)
    }


