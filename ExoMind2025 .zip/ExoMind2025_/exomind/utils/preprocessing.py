"""
Preprocessing Utilities
=======================

Utility functions for preprocessing lightcurve data.
"""

import numpy as np
import scipy.signal
from scipy import ndimage
from typing import Tuple, Optional


def normalize_flux(flux: np.ndarray, method: str = 'zscore') -> np.ndarray:
    """
    Normalize flux data.
    
    Args:
        flux: Input flux array
        method: Normalization method ('zscore', 'minmax', 'median')
        
    Returns:
        Normalized flux array
    """
    if method == 'zscore':
        return (flux - np.mean(flux)) / (np.std(flux) + 1e-8)
    elif method == 'minmax':
        return (flux - np.min(flux)) / (np.max(flux) - np.min(flux) + 1e-8)
    elif method == 'median':
        return flux / (np.median(flux) + 1e-8)
    else:
        raise ValueError(f"Unknown normalization method: {method}")


def detrend_flux(flux: np.ndarray, method: str = 'linear', window_size: int = 101) -> np.ndarray:
    """
    Remove trends from flux data.
    
    Args:
        flux: Input flux array
        method: Detrending method ('linear', 'savgol', 'median')
        window_size: Window size for filtering methods
        
    Returns:
        Detrended flux array
    """
    if method == 'linear':
        # Linear detrending
        x = np.arange(len(flux))
        coeffs = np.polyfit(x, flux, 1)
        trend = np.polyval(coeffs, x)
        return flux - trend
    
    elif method == 'savgol':
        # Savitzky-Golay filter
        if len(flux) < window_size:
            window_size = len(flux) // 3
            if window_size % 2 == 0:
                window_size += 1
        return flux - scipy.signal.savgol_filter(flux, window_size, 3)
    
    elif method == 'median':
        # Median filter
        if len(flux) < window_size:
            window_size = len(flux) // 3
        return flux - ndimage.median_filter(flux, size=window_size)
    
    else:
        raise ValueError(f"Unknown detrending method: {method}")


def remove_outliers(flux: np.ndarray, method: str = 'sigma', 
                   threshold: float = 3.0, window_size: int = 21) -> Tuple[np.ndarray, np.ndarray]:
    """
    Remove outliers from flux data.
    
    Args:
        flux: Input flux array
        method: Outlier detection method ('sigma', 'iqr', 'modified_zscore')
        threshold: Threshold for outlier detection
        window_size: Window size for local methods
        
    Returns:
        Tuple of (cleaned_flux, outlier_mask)
    """
    if method == 'sigma':
        # Sigma clipping
        mean_flux = np.mean(flux)
        std_flux = np.std(flux)
        outlier_mask = np.abs(flux - mean_flux) > threshold * std_flux
        
    elif method == 'iqr':
        # Interquartile range
        q25, q75 = np.percentile(flux, [25, 75])
        iqr = q75 - q25
        lower_bound = q25 - threshold * iqr
        upper_bound = q75 + threshold * iqr
        outlier_mask = (flux < lower_bound) | (flux > upper_bound)
        
    elif method == 'modified_zscore':
        # Modified Z-score using median
        median_flux = np.median(flux)
        mad = np.median(np.abs(flux - median_flux))
        modified_zscore = 0.6745 * (flux - median_flux) / mad
        outlier_mask = np.abs(modified_zscore) > threshold
        
    else:
        raise ValueError(f"Unknown outlier detection method: {method}")
    
    # Create cleaned flux (replace outliers with interpolated values)
    cleaned_flux = flux.copy()
    if np.any(outlier_mask):
        valid_indices = np.where(~outlier_mask)[0]
        outlier_indices = np.where(outlier_mask)[0]
        
        if len(valid_indices) > 1:
            # Interpolate outliers
            cleaned_flux[outlier_indices] = np.interp(
                outlier_indices, valid_indices, flux[valid_indices]
            )
    
    return cleaned_flux, outlier_mask


def smooth_flux(flux: np.ndarray, method: str = 'gaussian', 
               sigma: float = 1.0, window_size: int = 5) -> np.ndarray:
    """
    Smooth flux data.
    
    Args:
        flux: Input flux array
        method: Smoothing method ('gaussian', 'boxcar', 'median')
        sigma: Sigma for Gaussian smoothing
        window_size: Window size for smoothing
        
    Returns:
        Smoothed flux array
    """
    if method == 'gaussian':
        return ndimage.gaussian_filter1d(flux, sigma=sigma)
    elif method == 'boxcar':
        return scipy.signal.boxcar(window_size) @ flux / window_size
    elif method == 'median':
        return ndimage.median_filter(flux, size=window_size)
    else:
        raise ValueError(f"Unknown smoothing method: {method}")


def remove_systematic_noise(flux: np.ndarray, time: np.ndarray, 
                          period: float = 1.0) -> np.ndarray:
    """
    Remove systematic noise (e.g., spacecraft motion) with known period.
    
    Args:
        flux: Input flux array
        time: Time array
        period: Period of systematic noise
        
    Returns:
        Flux with systematic noise removed
    """
    # Create phase-folded lightcurve
    phase = (time % period) / period
    
    # Bin the data by phase
    n_bins = 100
    bin_edges = np.linspace(0, 1, n_bins + 1)
    bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2
    
    binned_flux = np.zeros(n_bins)
    bin_counts = np.zeros(n_bins)
    
    for i in range(n_bins):
        mask = (phase >= bin_edges[i]) & (phase < bin_edges[i + 1])
        if np.any(mask):
            binned_flux[i] = np.mean(flux[mask])
            bin_counts[i] = np.sum(mask)
    
    # Interpolate systematic pattern
    valid_bins = bin_counts > 0
    if np.sum(valid_bins) > 1:
        systematic_pattern = np.interp(phase, bin_centers[valid_bins], 
                                     binned_flux[valid_bins])
        return flux - systematic_pattern + np.mean(systematic_pattern)
    else:
        return flux


def prepare_for_model(flux: np.ndarray, time: Optional[np.ndarray] = None,
                     sequence_length: int = 1000, normalize: bool = True,
                     detrend: bool = True, remove_outliers_flag: bool = True) -> np.ndarray:
    """
    Complete preprocessing pipeline for model input.
    
    Args:
        flux: Input flux array
        time: Time array (optional)
        sequence_length: Target sequence length
        normalize: Whether to normalize
        detrend: Whether to detrend
        remove_outliers_flag: Whether to remove outliers
        
    Returns:
        Preprocessed flux array
    """
    processed_flux = flux.copy()
    
    # Remove outliers
    if remove_outliers_flag:
        processed_flux, _ = remove_outliers(processed_flux)
    
    # Detrend
    if detrend:
        processed_flux = detrend_flux(processed_flux)
    
    # Normalize
    if normalize:
        processed_flux = normalize_flux(processed_flux)
    
    # Ensure correct length
    if len(processed_flux) > sequence_length:
        # Take the middle portion
        start_idx = (len(processed_flux) - sequence_length) // 2
        processed_flux = processed_flux[start_idx:start_idx + sequence_length]
    elif len(processed_flux) < sequence_length:
        # Pad with zeros
        pad_width = sequence_length - len(processed_flux)
        processed_flux = np.pad(processed_flux, (0, pad_width), mode='constant')
    
    return processed_flux


