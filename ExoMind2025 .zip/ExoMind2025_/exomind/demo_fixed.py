"""
ExoMind Demo Script - Memory Optimized Version
==============================================

Demo script with memory optimizations to handle TensorFlow import issues.
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend to avoid memory issues
import matplotlib.pyplot as plt
import sys
import os

# Set TensorFlow environment variables before importing
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
os.environ['TF_FORCE_GPU_ALLOW_GROWTH'] = 'true'

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def generate_demo_lightcurve(n_points: int = 1000, has_transit: bool = True):
    """Generate a demo lightcurve."""
    # Time array
    time = np.linspace(0, 30, n_points)  # 30 days
    
    # Base flux with noise
    flux = np.random.normal(1.0, 0.001, n_points)
    
    # Add stellar variability
    flux += 0.002 * np.sin(2 * np.pi * time / 20.0)
    
    # Add transit if requested
    if has_transit:
        transit_params = {
            'period': 10.0,
            't0': 15.0,
            'duration': 0.5,
            'depth': 0.005
        }
        
        # Add synthetic transit
        transit_times = [transit_params['t0']]
        while transit_times[-1] + transit_params['period'] < time[-1]:
            transit_times.append(transit_times[-1] + transit_params['period'])
        
        for transit_time in transit_times:
            transit_start = transit_time - transit_params['duration'] / 2
            transit_end = transit_time + transit_params['duration'] / 2
            
            in_transit = (time >= transit_start) & (time <= transit_end)
            flux[in_transit] *= (1 - transit_params['depth'])
    
    return time, flux


def safe_import_tensorflow():
    """Safely import TensorFlow with memory management."""
    try:
        import gc
        gc.collect()  # Clean up before importing TF
        
        import tensorflow as tf
        print(f"✓ TensorFlow {tf.__version__} imported successfully")
        
        # Configure TensorFlow for memory efficiency
        tf.config.experimental.set_memory_growth(tf.config.list_physical_devices('GPU')[0], True) if tf.config.list_physical_devices('GPU') else None
        
        return tf
    except MemoryError as e:
        print(f"⚠ Memory error importing TensorFlow: {e}")
        return None
    except Exception as e:
        print(f"⚠ Error importing TensorFlow: {e}")
        return None


def demo_transit_detection():
    """Demo transit detection functionality with memory management."""
    print("ExoMind Transit Detection Demo - Memory Optimized")
    print("=" * 55)
    
    # Generate demo data
    print("1. Generating demo lightcurves...")
    
    # Lightcurve with transit
    time_with_transit, flux_with_transit = generate_demo_lightcurve(has_transit=True)
    
    # Lightcurve without transit
    time_no_transit, flux_no_transit = generate_demo_lightcurve(has_transit=False)
    
    print("✓ Lightcurves generated successfully")
    
    # Plot lightcurves
    print("\n2. Creating visualizations...")
    
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
    
    ax1.plot(time_with_transit, flux_with_transit, 'b-', alpha=0.7)
    ax1.set_title('Lightcurve with Transit')
    ax1.set_ylabel('Normalized Flux')
    ax1.grid(True, alpha=0.3)
    
    ax2.plot(time_no_transit, flux_no_transit, 'b-', alpha=0.7)
    ax2.set_title('Lightcurve without Transit')
    ax2.set_xlabel('Time (days)')
    ax2.set_ylabel('Normalized Flux')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('exomind_demo_lightcurves.png', dpi=150, bbox_inches='tight')
    print("✓ Lightcurves saved to 'exomind_demo_lightcurves.png'")
    
    # Try to import TensorFlow safely
    print("\n3. Attempting to import TensorFlow...")
    tf = safe_import_tensorflow()
    
    if tf is None:
        print("⚠ TensorFlow import failed - using simple statistical analysis")
        perform_simple_analysis(time_with_transit, flux_with_transit, 
                               time_no_transit, flux_no_transit)
    else:
        print("✓ TensorFlow imported - attempting ML model demo...")
        try:
            perform_ml_analysis(tf, time_with_transit, flux_with_transit, 
                               time_no_transit, flux_no_transit)
        except Exception as e:
            print(f"⚠ ML analysis failed: {e}")
            print("Falling back to simple statistical analysis...")
            perform_simple_analysis(time_with_transit, flux_with_transit, 
                                   time_no_transit, flux_no_transit)
    
    print("\n" + "=" * 55)
    print("Demo completed successfully!")
    print("=" * 55)


def perform_simple_analysis(time_with, flux_with, time_without, flux_without):
    """Perform simple statistical analysis when ML is not available."""
    print("\n4. Performing simple transit analysis...")
    
    # Calculate basic statistics
    flux_with_std = np.std(flux_with)
    flux_without_std = np.std(flux_without)
    
    # Simple transit detection using standard deviation
    threshold = 0.003  # Empirical threshold
    
    transit_detected_with = flux_with_std > threshold
    transit_detected_without = flux_without_std > threshold
    
    print(f"✓ Standard deviation with transit: {flux_with_std:.6f}")
    print(f"✓ Standard deviation without transit: {flux_without_std:.6f}")
    print(f"✓ Transit detected (with): {transit_detected_with}")
    print(f"✓ Transit detected (without): {transit_detected_without}")
    
    # Create analysis plot
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
    
    ax1.plot(time_with, flux_with, 'b-', alpha=0.7)
    ax1.set_title(f'Lightcurve with Transit (Std: {flux_with_std:.6f}, Detected: {transit_detected_with})')
    ax1.set_ylabel('Normalized Flux')
    ax1.grid(True, alpha=0.3)
    
    ax2.plot(time_without, flux_without, 'b-', alpha=0.7)
    ax2.set_title(f'Lightcurve without Transit (Std: {flux_without_std:.6f}, Detected: {transit_detected_without})')
    ax2.set_xlabel('Time (days)')
    ax2.set_ylabel('Normalized Flux')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('exomind_demo_simple_analysis.png', dpi=150, bbox_inches='tight')
    print("✓ Simple analysis results saved to 'exomind_demo_simple_analysis.png'")


def perform_ml_analysis(tf, time_with, flux_with, time_without, flux_without):
    """Perform ML analysis when TensorFlow is available."""
    print("\n4. Creating and training model...")
    
    # Import other modules safely
    try:
        from exomind.data.transit_dataset import TransitDataset
        from exomind.models.transit_detector import TransitDetector
        from exomind.utils.preprocessing import prepare_for_model
    except ImportError as e:
        print(f"⚠ Could not import ExoMind modules: {e}")
        raise
    
    # Create dataset
    dataset = TransitDataset(
        data_source='synthetic',
        mode='train',
        window_size=1000,
        batch_size=16
    )
    
    # Create model
    model = TransitDetector(
        input_shape=(1000, 1),
        model_type='cnn'
    )
    
    model.compile(
        optimizer='adam',
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )
    
    print("✓ Model created and compiled")
    
    # Train for a few epochs
    print("\n5. Training model (demo - 3 epochs)...")
    
    history = model.fit(
        dataset.get_dataset(),
        epochs=3,
        steps_per_epoch=5,  # Small number for demo
        verbose=1
    )
    
    print("✓ Model training completed")
    
    # Test prediction
    print("\n6. Testing predictions...")
    
    # Prepare test data
    test_flux_with_transit = prepare_for_model(flux_with, sequence_length=1000)
    test_flux_no_transit = prepare_for_model(flux_without, sequence_length=1000)
    
    # Make predictions
    pred_with_transit = model.predict(np.expand_dims(test_flux_with_transit, axis=(0, -1)), verbose=0)
    pred_no_transit = model.predict(np.expand_dims(test_flux_no_transit, axis=(0, -1)), verbose=0)
    
    prob_with_transit = pred_with_transit[0][1]
    prob_no_transit = pred_no_transit[0][1]
    
    print(f"✓ Prediction for lightcurve with transit: {prob_with_transit:.3f}")
    print(f"✓ Prediction for lightcurve without transit: {prob_no_transit:.3f}")
    
    # Create prediction plot
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
    
    ax1.plot(time_with, flux_with, 'b-', alpha=0.7)
    ax1.set_title(f'Lightcurve with Transit (Predicted Probability: {prob_with_transit:.3f})')
    ax1.set_ylabel('Normalized Flux')
    ax1.grid(True, alpha=0.3)
    
    ax2.plot(time_without, flux_without, 'b-', alpha=0.7)
    ax2.set_title(f'Lightcurve without Transit (Predicted Probability: {prob_no_transit:.3f})')
    ax2.set_xlabel('Time (days)')
    ax2.set_ylabel('Normalized Flux')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('exomind_demo_ml_predictions.png', dpi=150, bbox_inches='tight')
    print("✓ ML prediction results saved to 'exomind_demo_ml_predictions.png'")


if __name__ == "__main__":
    demo_transit_detection()
