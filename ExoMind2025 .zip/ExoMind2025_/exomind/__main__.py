"""
ExoMind Package Entry Point
===========================

This allows running the ExoMind server using:
    python -m exomind

Or specific submodules using:
    python -m exomind.api.server
"""

import sys
import os

# Add the package root to Python path
package_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if package_root not in sys.path:
    sys.path.insert(0, package_root)

if __name__ == '__main__':
    # Default to running the server if no submodule is specified
    from exomind.api.server import run_server
    run_server()
