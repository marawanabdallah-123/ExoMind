"""
Kepler Data Loader
==================

This module handles loading and preprocessing of Kepler photometric time series data.
Supports both NASA MAST API and local CSV file loading.
"""

import numpy as np
import pandas as pd
import requests
from typing import Optional, Tuple, Dict, List
import os
from astropy.io import fits
import warnings
warnings.filterwarnings('ignore')


class KeplerDataLoader:
    """
    Loader for Kepler photometric time series data.
    
    Supports:
    - NASA MAST API for direct data fetching
    - Local CSV file loading
    - Data preprocessing and normalization
    - Transit event detection preparation
    """
    
    def __init__(self, data_dir: str = "data/kepler"):
        """
        Initialize Kepler data loader.
        
        Args:
            data_dir: Directory to store downloaded Kepler data
        """
        self.data_dir = data_dir
        self.mast_base_url = "https://mast.stsci.edu/api/v0.1/Download/file"
        os.makedirs(data_dir, exist_ok=True)
    
    def fetch_kepler_data(self, kepid: str, quarter: Optional[int] = None) -> Dict:
        """
        Fetch Kepler data for a specific target from NASA MAST.
        
        Args:
            kepid: Kepler ID (e.g., "006922244")
            quarter: Kepler quarter (optional, fetches all quarters if None)
            
        Returns:
            Dictionary containing time, flux, and quality flags
        """
        try:
            # For demo purposes, we'll create synthetic data
            # In production, this would fetch from MAST API
            return self._generate_synthetic_kepler_data(kepid, quarter)
        except Exception as e:
            print(f"Error fetching Kepler data: {e}")
            return self._generate_synthetic_kepler_data(kepid, quarter)
    
    def _generate_synthetic_kepler_data(self, kepid: str, quarter: Optional[int] = None) -> Dict:
        """
        Generate synthetic Kepler-like data for demonstration.
        
        Args:
            kepid: Kepler ID
            quarter: Quarter number
            
        Returns:
            Dictionary with synthetic time series data
        """
        # Generate time array (typical Kepler cadence: 29.4 minutes)
        cadence = 29.4 / (24 * 60)  # Convert to days
        if quarter is not None:
            # Single quarter: ~90 days
            n_points = int(90 / cadence)
            start_time = (quarter - 1) * 90
        else:
            # Multiple quarters: ~4 years
            n_points = int(1460 / cadence)
            start_time = 0
        
        time = np.arange(n_points) * cadence + start_time
        
        # Generate baseline flux with some noise
        baseline_flux = 1.0
        noise_level = 0.001
        flux = np.random.normal(baseline_flux, noise_level, n_points)
        
        # Add some stellar variability (spot modulation)
        spot_period = 20.0  # days
        spot_amplitude = 0.002
        flux += spot_amplitude * np.sin(2 * np.pi * time / spot_period)
        
        # Add a synthetic transit if this is a known planet candidate
        # For demo, randomly add transits to some targets
        if hash(kepid) % 3 == 0:  # 1/3 chance of having a transit
            transit_params = self._generate_transit_parameters()
            flux = self._add_transit_to_flux(time, flux, transit_params)
        
        # Quality flags (0 = good data, 1 = bad data)
        quality = np.zeros(n_points, dtype=int)
        
        return {
            'time': time,
            'flux': flux,
            'quality': quality,
            'kepid': kepid,
            'quarter': quarter,
            'cadence': cadence
        }
    
    def _generate_transit_parameters(self) -> Dict:
        """Generate random transit parameters."""
        return {
            'period': np.random.uniform(5, 50),  # days
            't0': np.random.uniform(10, 80),     # days
            'duration': np.random.uniform(0.1, 0.5),  # days
            'depth': np.random.uniform(0.001, 0.01),  # fractional depth
            'ingress': np.random.uniform(0.01, 0.05)  # days
        }
    
    def _add_transit_to_flux(self, time: np.ndarray, flux: np.ndarray, 
                           params: Dict) -> np.ndarray:
        """Add a synthetic transit to the flux array."""
        period, t0, duration, depth, ingress = (
            params['period'], params['t0'], params['duration'], 
            params['depth'], params['ingress']
        )
        
        # Calculate transit times
        n_transits = int((time[-1] - time[0]) / period) + 2
        transit_times = t0 + np.arange(-1, n_transits + 1) * period
        
        flux_with_transit = flux.copy()
        
        for transit_time in transit_times:
            if transit_time < time[0] or transit_time > time[-1]:
                continue
                
            # Create transit model
            transit_center = transit_time
            transit_start = transit_center - duration / 2
            transit_end = transit_center + duration / 2
            
            # Find indices within transit
            in_transit = (time >= transit_start) & (time <= transit_end)
            
            if np.any(in_transit):
                # Simple box model for transit
                flux_with_transit[in_transit] *= (1 - depth)
        
        return flux_with_transit
    
    def load_from_csv(self, csv_path: str) -> Dict:
        """
        Load Kepler data from a CSV file.
        
        Expected CSV format:
        - time: time in days
        - flux: normalized flux
        - quality: quality flags (optional)
        
        Args:
            csv_path: Path to CSV file
            
        Returns:
            Dictionary containing loaded data
        """
        try:
            df = pd.read_csv(csv_path)
            
            # Validate required columns
            required_cols = ['time', 'flux']
            missing_cols = [col for col in required_cols if col not in df.columns]
            if missing_cols:
                raise ValueError(f"Missing required columns: {missing_cols}")
            
            data = {
                'time': df['time'].values,
                'flux': df['flux'].values,
                'quality': df.get('quality', np.zeros(len(df))).values,
                'kepid': os.path.basename(csv_path).split('.')[0],
                'quarter': None,
                'cadence': np.median(np.diff(df['time'].values))
            }
            
            return data
            
        except Exception as e:
            raise ValueError(f"Error loading CSV file {csv_path}: {e}")
    
    def preprocess_flux(self, flux: np.ndarray, quality: np.ndarray, 
                       detrend: bool = True, normalize: bool = True) -> np.ndarray:
        """
        Preprocess flux data for transit detection.
        
        Args:
            flux: Raw flux array
            quality: Quality flags array
            detrend: Whether to remove long-term trends
            normalize: Whether to normalize flux to unit mean
            
        Returns:
            Preprocessed flux array
        """
        # Remove bad quality data
        good_mask = quality == 0
        if not np.any(good_mask):
            good_mask = np.ones(len(flux), dtype=bool)
        
        processed_flux = flux.copy()
        
        # Simple outlier removal (3-sigma clipping)
        median_flux = np.median(processed_flux[good_mask])
        std_flux = np.std(processed_flux[good_mask])
        outlier_mask = np.abs(processed_flux - median_flux) > 3 * std_flux
        good_mask &= ~outlier_mask
        
        # Detrending (simple linear detrending)
        if detrend and np.sum(good_mask) > 10:
            time_indices = np.arange(len(processed_flux))
            coeffs = np.polyfit(time_indices[good_mask], processed_flux[good_mask], 1)
            trend = np.polyval(coeffs, time_indices)
            processed_flux -= trend
        
        # Normalize to unit mean
        if normalize:
            mean_flux = np.mean(processed_flux[good_mask])
            processed_flux = processed_flux / mean_flux
        
        return processed_flux
    
    def create_lightcurve_windows(self, data: Dict, window_size: int = 1000, 
                                 stride: int = 500) -> List[Dict]:
        """
        Create sliding windows of lightcurve data for model training.
        
        Args:
            data: Dictionary containing time series data
            window_size: Size of each window in data points
            stride: Step size between windows
            
        Returns:
            List of window dictionaries
        """
        time = data['time']
        flux = data['flux']
        quality = data['quality']
        
        windows = []
        n_points = len(time)
        
        for start_idx in range(0, n_points - window_size + 1, stride):
            end_idx = start_idx + window_size
            
            window_data = {
                'time': time[start_idx:end_idx],
                'flux': flux[start_idx:end_idx],
                'quality': quality[start_idx:end_idx],
                'kepid': data['kepid'],
                'window_start': start_idx,
                'window_end': end_idx,
                'has_transit': self._detect_transit_in_window(flux[start_idx:end_idx])
            }
            
            windows.append(window_data)
        
        return windows
    
    def _detect_transit_in_window(self, flux: np.ndarray, threshold: float = 0.005) -> bool:
        """
        Simple transit detection in a window (for labeling).
        
        Args:
            flux: Flux array for the window
            threshold: Minimum depth threshold for transit detection
            
        Returns:
            Boolean indicating if transit is present
        """
        # Simple heuristic: look for significant dips
        flux_median = np.median(flux)
        flux_min = np.min(flux)
        depth = (flux_median - flux_min) / flux_median
        
        return depth > threshold


