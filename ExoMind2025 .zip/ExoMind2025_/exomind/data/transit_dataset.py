"""
Transit Dataset
===============

This module provides a TensorFlow dataset class for exoplanet transit detection,
adapted from AstroNet's dataset infrastructure but designed for 1D time series data.
"""

import tensorflow as tf
import numpy as np
from typing import Dict, List, Tuple, Optional
import os
from sklearn.utils.class_weight import compute_class_weight


class TransitDataset:
    """
    TensorFlow dataset class for exoplanet transit detection.
    
    Adapts AstroNet's dataset infrastructure for 1D time series data instead of 2D images.
    """
    
    def __init__(self, 
                 data_source: str = 'synthetic',
                 mode: str = 'train',
                 window_size: int = 1000,
                 stride: int = 500,
                 batch_size: int = 32,
                 buffer_size: int = 1000,
                 prefetch_size: int = 1,
                 kepler_loader=None,
                 tess_loader=None):
        """
        Initialize transit dataset.
        
        Args:
            data_source: Source of data ('synthetic', 'kepler', 'tess')
            mode: Dataset mode ('train', 'validation', 'test')
            window_size: Size of time series windows
            stride: Step size between windows
            batch_size: Batch size for training
            buffer_size: Buffer size for shuffling
            prefetch_size: Prefetch size for performance
            kepler_loader: Kepler data loader instance
            tess_loader: TESS data loader instance
        """
        self.mode = mode
        self.data_source = data_source
        self.window_size = window_size
        self.stride = stride
        self.batch_size = batch_size
        self.buffer_size = buffer_size
        self.prefetch_size = prefetch_size
        
        self.kepler_loader = kepler_loader
        self.tess_loader = tess_loader
        
        # Generate or load data
        if data_source == 'synthetic':
            self.data = self._generate_synthetic_dataset()
        elif data_source == 'kepler' and kepler_loader:
            self.data = self._load_kepler_data()
        elif data_source == 'tess' and tess_loader:
            self.data = self._load_tess_data()
        else:
            raise ValueError(f"Invalid data source: {data_source}")
        
        # Compute class weights
        self.class_weights = self._compute_class_weights()
    
    def _generate_synthetic_dataset(self) -> List[Dict]:
        """Generate synthetic dataset for demonstration."""
        print(f"Generating synthetic {self.mode} dataset...")
        
        # Determine dataset size based on mode
        if self.mode == 'train':
            n_targets = 1000
        elif self.mode == 'validation':
            n_targets = 200
        else:  # test
            n_targets = 100
        
        dataset = []
        
        for i in range(n_targets):
            # Generate synthetic lightcurve
            time = np.linspace(0, 30, self.window_size)  # 30 days
            
            # Base flux with noise
            flux = np.random.normal(1.0, 0.001, self.window_size)
            
            # Add stellar variability
            flux += 0.002 * np.sin(2 * np.pi * time / 20.0)
            
            # Randomly add transits (50% chance for training, fixed for validation/test)
            has_transit = False
            if self.mode == 'train':
                has_transit = np.random.random() < 0.5
            elif self.mode == 'validation':
                has_transit = i % 2 == 0  # 50% for validation
            else:  # test
                has_transit = i % 3 == 0  # 33% for test
            
            if has_transit:
                # Add synthetic transit
                transit_params = self._generate_transit_params()
                flux = self._add_transit_to_flux(time, flux, transit_params)
            
            # Create window data
            window_data = {
                'time': time,
                'flux': flux,
                'has_transit': has_transit,
                'target_id': f'synthetic_{i:06d}',
                'transit_params': transit_params if has_transit else None
            }
            
            dataset.append(window_data)
        
        print(f"Generated {len(dataset)} {self.mode} samples")
        return dataset
    
    def _generate_transit_params(self) -> Dict:
        """Generate random transit parameters."""
        return {
            'period': np.random.uniform(5, 50),
            't0': np.random.uniform(5, 25),
            'duration': np.random.uniform(0.1, 0.5),
            'depth': np.random.uniform(0.001, 0.01),
            'ingress': np.random.uniform(0.01, 0.05)
        }
    
    def _add_transit_to_flux(self, time: np.ndarray, flux: np.ndarray, 
                           params: Dict) -> np.ndarray:
        """Add synthetic transit to flux."""
        period, t0, duration, depth, ingress = (
            params['period'], params['t0'], params['duration'],
            params['depth'], params['ingress']
        )
        
        # Find transit times within the window
        transit_times = []
        current_time = t0
        while current_time < time[-1]:
            if current_time >= time[0]:
                transit_times.append(current_time)
            current_time += period
        
        flux_with_transit = flux.copy()
        
        for transit_time in transit_times:
            transit_start = transit_time - duration / 2
            transit_end = transit_time + duration / 2
            
            in_transit = (time >= transit_start) & (time <= transit_end)
            flux_with_transit[in_transit] *= (1 - depth)
        
        return flux_with_transit
    
    def _load_kepler_data(self) -> List[Dict]:
        """Load Kepler data using the Kepler loader."""
        # This would integrate with the Kepler loader
        # For now, return synthetic data
        return self._generate_synthetic_dataset()
    
    def _load_tess_data(self) -> List[Dict]:
        """Load TESS data using the TESS loader."""
        # This would integrate with the TESS loader
        # For now, return synthetic data
        return self._generate_synthetic_dataset()
    
    def _compute_class_weights(self) -> Dict:
        """Compute class weights for imbalanced dataset."""
        labels = [int(item['has_transit']) for item in self.data]
        unique_labels = np.unique(labels)
        
        if len(unique_labels) > 1:
            class_weights = compute_class_weight(
                'balanced',
                classes=unique_labels,
                y=labels
            )
            class_weight_dict = {i: weight for i, weight in enumerate(class_weights)}
        else:
            class_weight_dict = {0: 1.0, 1: 1.0}
        
        return class_weight_dict
    
    def map_features(self, item: Dict) -> Dict:
        """
        Map raw data to model inputs.
        
        Args:
            item: Raw data item
            
        Returns:
            Mapped features for model input
        """
        flux = item['flux']
        
        # Normalize flux
        flux_mean = tf.reduce_mean(flux)
        flux_std = tf.reduce_std(flux)
        flux_normalized = (flux - flux_mean) / (flux_std + 1e-8)
        
        # Add channel dimension for Conv1D layers
        flux_input = tf.expand_dims(flux_normalized, axis=-1)
        
        # Create label
        label = tf.cast(item['has_transit'], tf.float32)
        
        # Get class weight
        class_weight = self.class_weights.get(int(item['has_transit']), 1.0)
        
        return {
            'flux': flux_input,
            'label': label,
            'class_weight': tf.constant(class_weight, dtype=tf.float32),
            'target_id': item['target_id']
        }
    
    def get_dataset(self) -> tf.data.Dataset:
        """
        Get TensorFlow dataset.
        
        Returns:
            Configured TensorFlow dataset
        """
        # Convert to TensorFlow dataset
        dataset = tf.data.Dataset.from_generator(
            lambda: iter(self.data),
            output_signature={
                'flux': tf.TensorSpec(shape=(self.window_size,), dtype=tf.float32),
                'has_transit': tf.TensorSpec(shape=(), dtype=tf.bool),
                'target_id': tf.TensorSpec(shape=(), dtype=tf.string)
            }
        )
        
        # Map features
        dataset = dataset.map(self.map_features)
        
        # Shuffle and repeat for training
        if self.mode == 'train':
            dataset = dataset.shuffle(self.buffer_size).repeat()
        
        # Batch and prefetch
        dataset = dataset.batch(self.batch_size).prefetch(self.prefetch_size)
        
        return dataset
    
    def get_stats(self) -> Dict:
        """Get dataset statistics."""
        total_samples = len(self.data)
        transit_samples = sum(1 for item in self.data if item['has_transit'])
        no_transit_samples = total_samples - transit_samples
        
        return {
            'total_samples': total_samples,
            'transit_samples': transit_samples,
            'no_transit_samples': no_transit_samples,
            'transit_fraction': transit_samples / total_samples,
            'class_weights': self.class_weights
        }


