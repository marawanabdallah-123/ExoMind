"""
ExoMind Simple Demo Script
==========================

Lightweight demo script that doesn't require TensorFlow to avoid memory issues.
Shows basic functionality without heavy ML imports.
"""

import numpy as np
import matplotlib.pyplot as plt
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Only import non-TensorFlow modules
from exomind.utils.visualization import plot_lightcurve
from exomind.utils.preprocessing import prepare_for_model


def generate_demo_lightcurve(n_points: int = 1000, has_transit: bool = True):
    """Generate a demo lightcurve."""
    # Time array
    time = np.linspace(0, 30, n_points)  # 30 days
    
    # Base flux with noise
    flux = np.random.normal(1.0, 0.001, n_points)
    
    # Add stellar variability
    flux += 0.002 * np.sin(2 * np.pi * time / 20.0)
    
    # Add transit if requested
    if has_transit:
        transit_params = {
            'period': 10.0,
            't0': 15.0,
            'duration': 0.5,
            'depth': 0.005
        }
        
        # Add synthetic transit
        transit_times = [transit_params['t0']]
        while transit_times[-1] + transit_params['period'] < time[-1]:
            transit_times.append(transit_times[-1] + transit_params['period'])
        
        for transit_time in transit_times:
            transit_start = transit_time - transit_params['duration'] / 2
            transit_end = transit_time + transit_params['duration'] / 2
            
            in_transit = (time >= transit_start) & (time <= transit_end)
            flux[in_transit] *= (1 - transit_params['depth'])
    
    return time, flux


def simple_transit_detection():
    """Simple transit detection demo without TensorFlow."""
    print("ExoMind Simple Transit Detection Demo")
    print("=" * 45)
    
    # Generate demo data
    print("1. Generating demo lightcurves...")
    
    # Lightcurve with transit
    time_with_transit, flux_with_transit = generate_demo_lightcurve(has_transit=True)
    
    # Lightcurve without transit
    time_no_transit, flux_no_transit = generate_demo_lightcurve(has_transit=False)
    
    print("✓ Lightcurves generated successfully")
    
    # Plot lightcurves
    print("\n2. Creating visualizations...")
    
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
    
    ax1.plot(time_with_transit, flux_with_transit, 'b-', alpha=0.7)
    ax1.set_title('Lightcurve with Transit')
    ax1.set_ylabel('Normalized Flux')
    ax1.grid(True, alpha=0.3)
    
    ax2.plot(time_no_transit, flux_no_transit, 'b-', alpha=0.7)
    ax2.set_title('Lightcurve without Transit')
    ax2.set_xlabel('Time (days)')
    ax2.set_ylabel('Normalized Flux')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('exomind_simple_demo_lightcurves.png', dpi=150, bbox_inches='tight')
    print("✓ Lightcurves saved to 'exomind_simple_demo_lightcurves.png'")
    
    # Simple statistical analysis
    print("\n3. Performing simple transit analysis...")
    
    # Calculate basic statistics
    flux_with_transit_std = np.std(flux_with_transit)
    flux_no_transit_std = np.std(flux_no_transit)
    
    # Simple transit detection using standard deviation
    threshold = 0.003  # Empirical threshold
    
    transit_detected_with = flux_with_transit_std > threshold
    transit_detected_without = flux_no_transit_std > threshold
    
    print(f"✓ Standard deviation with transit: {flux_with_transit_std:.6f}")
    print(f"✓ Standard deviation without transit: {flux_no_transit_std:.6f}")
    print(f"✓ Transit detected (with): {transit_detected_with}")
    print(f"✓ Transit detected (without): {transit_detected_without}")
    
    # Create analysis plot
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
    
    ax1.plot(time_with_transit, flux_with_transit, 'b-', alpha=0.7)
    ax1.set_title(f'Lightcurve with Transit (Std: {flux_with_transit_std:.6f}, Detected: {transit_detected_with})')
    ax1.set_ylabel('Normalized Flux')
    ax1.grid(True, alpha=0.3)
    
    ax2.plot(time_no_transit, flux_no_transit, 'b-', alpha=0.7)
    ax2.set_title(f'Lightcurve without Transit (Std: {flux_no_transit_std:.6f}, Detected: {transit_detected_without})')
    ax2.set_xlabel('Time (days)')
    ax2.set_ylabel('Normalized Flux')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('exomind_simple_demo_analysis.png', dpi=150, bbox_inches='tight')
    print("✓ Analysis results saved to 'exomind_simple_demo_analysis.png'")
    
    print("\n" + "=" * 45)
    print("Simple demo completed successfully!")
    print("Note: This demo uses basic statistical analysis instead of ML models")
    print("to avoid memory issues with TensorFlow.")
    print("=" * 45)


if __name__ == "__main__":
    simple_transit_detection()
