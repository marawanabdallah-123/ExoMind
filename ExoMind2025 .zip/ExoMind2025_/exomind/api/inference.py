"""
Transit Inference API
======================

API class for exoplanet transit detection inference.
"""

import numpy as np
import tensorflow as tf
from typing import Dict, List, Optional, Union
import json
import os
from pathlib import Path

from ..models.transit_detector import TransitDetector
from ..utils.preprocessing import prepare_for_model
from ..utils.metrics import evaluate_model_performance


class TransitInferenceAPI:
    """
    API class for transit detection inference.
    
    Provides methods for loading models, preprocessing data, and making predictions.
    """
    
    def __init__(self, model_path: Optional[str] = None, 
                 model_type: str = 'cnn',
                 sequence_length: int = 1000):
        """
        Initialize inference API.
        
        Args:
            model_path: Path to saved model weights
            model_type: Type of model ('cnn', 'lstm', 'hybrid')
            sequence_length: Expected input sequence length
        """
        self.model_path = model_path
        self.model_type = model_type
        self.sequence_length = sequence_length
        self.model = None
        self.is_loaded = False
        
        # Load model if path is provided
        if model_path and os.path.exists(model_path):
            self.load_model(model_path)
    
    def load_model(self, model_path: str) -> bool:
        """
        Load a trained model.
        
        Args:
            model_path: Path to model weights or full model
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Try loading as full model first
            if model_path.endswith('.h5') or model_path.endswith('.hdf5'):
                self.model = tf.keras.models.load_model(model_path)
            else:
                # Load as weights only
                input_shape = (self.sequence_length, 1)
                self.model = TransitDetector(
                    input_shape=input_shape,
                    model_type=self.model_type
                )
                self.model.load_weights(model_path)
            
            self.is_loaded = True
            self.model_path = model_path
            print(f"Model loaded successfully from {model_path}")
            return True
            
        except Exception as e:
            print(f"Error loading model: {e}")
            return False
    
    def predict_single(self, flux_data: Union[np.ndarray, List[float]], 
                      threshold: float = 0.5) -> Dict:
        """
        Predict transit probability for a single lightcurve.
        
        Args:
            flux_data: 1D array of flux values
            threshold: Classification threshold
            
        Returns:
            Dictionary with prediction results
        """
        if not self.is_loaded:
            return {
                'error': 'Model not loaded',
                'has_transit': False,
                'confidence': 0.0
            }
        
        try:
            # Convert to numpy array
            flux = np.array(flux_data, dtype=np.float32)
            
            # Preprocess
            processed_flux = prepare_for_model(
                flux, 
                sequence_length=self.sequence_length
            )
            
            # Reshape for model input
            flux_input = np.expand_dims(processed_flux, axis=(0, -1))
            
            # Predict
            prediction = self.model.predict(flux_input, verbose=0)
            probability = float(prediction[0][1])  # Probability of transit
            
            return {
                'has_transit': probability > threshold,
                'confidence': probability,
                'threshold': threshold,
                'input_length': len(flux),
                'processed_length': len(processed_flux)
            }
            
        except Exception as e:
            return {
                'error': f'Prediction failed: {str(e)}',
                'has_transit': False,
                'confidence': 0.0
            }
    
    def predict_batch(self, flux_data_list: List[Union[np.ndarray, List[float]]], 
                     threshold: float = 0.5) -> List[Dict]:
        """
        Predict transit probabilities for multiple lightcurves.
        
        Args:
            flux_data_list: List of 1D flux arrays
            threshold: Classification threshold
            
        Returns:
            List of prediction dictionaries
        """
        predictions = []
        
        for i, flux_data in enumerate(flux_data_list):
            prediction = self.predict_single(flux_data, threshold)
            prediction['index'] = i
            predictions.append(prediction)
        
        return predictions
    
    def predict_from_csv(self, csv_path: str, 
                        time_column: str = 'time',
                        flux_column: str = 'flux',
                        threshold: float = 0.5) -> Dict:
        """
        Predict transit probability from CSV file.
        
        Args:
            csv_path: Path to CSV file
            time_column: Name of time column
            flux_column: Name of flux column
            threshold: Classification threshold
            
        Returns:
            Dictionary with prediction results
        """
        try:
            import pandas as pd
            
            # Load CSV
            df = pd.read_csv(csv_path)
            
            if flux_column not in df.columns:
                return {
                    'error': f'Flux column "{flux_column}" not found in CSV',
                    'has_transit': False,
                    'confidence': 0.0
                }
            
            # Extract flux data
            flux_data = df[flux_column].values
            
            # Get time data if available
            time_data = None
            if time_column in df.columns:
                time_data = df[time_column].values
            
            # Make prediction
            prediction = self.predict_single(flux_data, threshold)
            
            # Add metadata
            prediction['csv_file'] = csv_path
            prediction['n_data_points'] = len(flux_data)
            if time_data is not None:
                prediction['time_range'] = {
                    'start': float(time_data[0]),
                    'end': float(time_data[-1]),
                    'duration': float(time_data[-1] - time_data[0])
                }
            
            return prediction
            
        except Exception as e:
            return {
                'error': f'CSV processing failed: {str(e)}',
                'has_transit': False,
                'confidence': 0.0
            }
    
    def evaluate_model(self, y_true: np.ndarray, y_pred: np.ndarray, 
                      y_prob: Optional[np.ndarray] = None) -> Dict:
        """
        Evaluate model performance.
        
        Args:
            y_true: True labels
            y_pred: Predicted labels
            y_prob: Predicted probabilities
            
        Returns:
            Dictionary with evaluation metrics
        """
        return evaluate_model_performance(y_true, y_pred, y_prob)
    
    def get_model_info(self) -> Dict:
        """
        Get model information.
        
        Returns:
            Dictionary with model information
        """
        info = {
            'is_loaded': self.is_loaded,
            'model_path': self.model_path,
            'model_type': self.model_type,
            'sequence_length': self.sequence_length
        }
        
        if self.is_loaded and self.model is not None:
            try:
                info['input_shape'] = self.model.input_shape
                info['output_shape'] = self.model.output_shape
                info['total_params'] = self.model.count_params()
            except:
                info['model_details'] = 'Unable to extract model details'
        
        return info
    
    def save_prediction_results(self, predictions: List[Dict], 
                              output_path: str) -> bool:
        """
        Save prediction results to JSON file.
        
        Args:
            predictions: List of prediction dictionaries
            output_path: Path to output JSON file
            
        Returns:
            True if successful, False otherwise
        """
        try:
            with open(output_path, 'w') as f:
                json.dump(predictions, f, indent=2)
            return True
        except Exception as e:
            print(f"Error saving results: {e}")
            return False
    
    def create_summary_report(self, predictions: List[Dict]) -> Dict:
        """
        Create summary report from predictions.
        
        Args:
            predictions: List of prediction dictionaries
            
        Returns:
            Dictionary with summary statistics
        """
        total_predictions = len(predictions)
        transit_predictions = sum(1 for p in predictions if p.get('has_transit', False))
        avg_confidence = np.mean([p.get('confidence', 0) for p in predictions])
        
        confidence_distribution = {
            'high_confidence': sum(1 for p in predictions if p.get('confidence', 0) > 0.8),
            'medium_confidence': sum(1 for p in predictions if 0.5 < p.get('confidence', 0) <= 0.8),
            'low_confidence': sum(1 for p in predictions if p.get('confidence', 0) <= 0.5)
        }
        
        return {
            'total_predictions': total_predictions,
            'transit_predictions': transit_predictions,
            'transit_rate': transit_predictions / total_predictions if total_predictions > 0 else 0,
            'average_confidence': avg_confidence,
            'confidence_distribution': confidence_distribution
        }


