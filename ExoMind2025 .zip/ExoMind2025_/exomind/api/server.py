"""
Flask Server for ExoMind API
=============================

Web server for ExoMind transit detection API.
"""

from flask import Flask, request, jsonify, render_template_string
import numpy as np
import pandas as pd
from werkzeug.utils import secure_filename
import os
import tempfile
from typing import Dict, Any

from .inference import TransitInferenceAPI


def create_app(model_path: str = None, model_type: str = 'cnn') -> Flask:
    """
    Create Flask application.
    
    Args:
        model_path: Path to trained model
        model_type: Type of model ('cnn', 'lstm', 'hybrid')
        
    Returns:
        Flask application instance
    """
    app = Flask(__name__)
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
    
    # Initialize inference API
    inference_api = TransitInferenceAPI(model_path=model_path, model_type=model_type)
    
    # HTML template for the web interface
    HTML_TEMPLATE = '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>ExoMind Transit Detection</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background-color: #f5f5f5; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            h1 { color: #2c3e50; text-align: center; }
            .upload-section { margin: 20px 0; padding: 20px; border: 2px dashed #3498db; border-radius: 5px; text-align: center; }
            .result-section { margin: 20px 0; padding: 20px; background-color: #ecf0f1; border-radius: 5px; }
            .transit-detected { background-color: #e8f5e8; border-left: 4px solid #27ae60; }
            .no-transit { background-color: #f8f9fa; border-left: 4px solid #95a5a6; }
            button { background-color: #3498db; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; }
            button:hover { background-color: #2980b9; }
            .loading { display: none; color: #7f8c8d; }
            .error { color: #e74c3c; background-color: #fdf2f2; padding: 10px; border-radius: 5px; margin: 10px 0; }
            .success { color: #27ae60; background-color: #f0f9f0; padding: 10px; border-radius: 5px; margin: 10px 0; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🚀 ExoMind Transit Detection</h1>
            <p style="text-align: center; color: #7f8c8d;">Upload a lightcurve CSV file to detect exoplanet transits</p>
            
            <div class="upload-section">
                <form id="uploadForm" enctype="multipart/form-data">
                    <input type="file" id="fileInput" name="file" accept=".csv" required>
                    <br><br>
                    <button type="submit">Analyze Lightcurve</button>
                </form>
                <div class="loading" id="loading">Analyzing lightcurve...</div>
            </div>
            
            <div id="resultSection" class="result-section" style="display: none;">
                <h3>Analysis Results</h3>
                <div id="resultContent"></div>
            </div>
        </div>
        
        <script>
            document.getElementById('uploadForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const fileInput = document.getElementById('fileInput');
                const loading = document.getElementById('loading');
                const resultSection = document.getElementById('resultSection');
                const resultContent = document.getElementById('resultContent');
                
                if (!fileInput.files[0]) {
                    alert('Please select a CSV file');
                    return;
                }
                
                loading.style.display = 'block';
                resultSection.style.display = 'none';
                
                const formData = new FormData();
                formData.append('file', fileInput.files[0]);
                
                try {
                    const response = await fetch('/predict_csv', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const result = await response.json();
                    loading.style.display = 'none';
                    
                    if (result.error) {
                        resultContent.innerHTML = `<div class="error">Error: ${result.error}</div>`;
                    } else {
                        const hasTransit = result.has_transit;
                        const confidence = (result.confidence * 100).toFixed(1);
                        const className = hasTransit ? 'transit-detected' : 'no-transit';
                        const status = hasTransit ? '🚀 TRANSIT DETECTED!' : '❌ No Transit Detected';
                        
                        resultContent.innerHTML = `
                            <div class="${className}">
                                <h4>${status}</h4>
                                <p><strong>Confidence:</strong> ${confidence}%</p>
                                <p><strong>Threshold:</strong> ${(result.threshold * 100).toFixed(1)}%</p>
                                <p><strong>Data Points:</strong> ${result.n_data_points}</p>
                                ${result.time_range ? `<p><strong>Time Range:</strong> ${result.time_range.start.toFixed(2)} - ${result.time_range.end.toFixed(2)} days</p>` : ''}
                            </div>
                        `;
                    }
                    
                    resultSection.style.display = 'block';
                } catch (error) {
                    loading.style.display = 'none';
                    resultContent.innerHTML = `<div class="error">Error: ${error.message}</div>`;
                    resultSection.style.display = 'block';
                }
            });
        </script>
    </body>
    </html>
    '''
    
    @app.route('/')
    def index():
        """Main page."""
        return render_template_string(HTML_TEMPLATE)
    
    @app.route('/health')
    def health():
        """Health check endpoint."""
        model_info = inference_api.get_model_info()
        return jsonify({
            'status': 'healthy',
            'model_loaded': model_info['is_loaded'],
            'model_type': model_info['model_type']
        })
    
    @app.route('/predict', methods=['POST'])
    def predict():
        """Predict transit probability from JSON data."""
        try:
            data = request.get_json()
            
            if not data or 'flux' not in data:
                return jsonify({'error': 'Flux data required'}), 400
            
            flux_data = data['flux']
            threshold = data.get('threshold', 0.5)
            
            result = inference_api.predict_single(flux_data, threshold)
            return jsonify(result)
            
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    @app.route('/predict_csv', methods=['POST'])
    def predict_csv():
        """Predict transit probability from uploaded CSV file."""
        try:
            if 'file' not in request.files:
                return jsonify({'error': 'No file uploaded'}), 400
            
            file = request.files['file']
            if file.filename == '':
                return jsonify({'error': 'No file selected'}), 400
            
            if not file.filename.endswith('.csv'):
                return jsonify({'error': 'File must be a CSV'}), 400
            
            # Save uploaded file temporarily
            with tempfile.NamedTemporaryFile(delete=False, suffix='.csv') as tmp_file:
                file.save(tmp_file.name)
                
                try:
                    # Get parameters from form data
                    time_column = request.form.get('time_column', 'time')
                    flux_column = request.form.get('flux_column', 'flux')
                    threshold = float(request.form.get('threshold', 0.5))
                    
                    # Make prediction
                    result = inference_api.predict_from_csv(
                        tmp_file.name, 
                        time_column=time_column,
                        flux_column=flux_column,
                        threshold=threshold
                    )
                    
                    return jsonify(result)
                    
                finally:
                    # Clean up temporary file
                    os.unlink(tmp_file.name)
                    
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    @app.route('/model_info')
    def model_info():
        """Get model information."""
        return jsonify(inference_api.get_model_info())
    
    @app.route('/predict_batch', methods=['POST'])
    def predict_batch():
        """Predict transit probabilities for multiple lightcurves."""
        try:
            data = request.get_json()
            
            if not data or 'flux_data' not in data:
                return jsonify({'error': 'Flux data array required'}), 400
            
            flux_data_list = data['flux_data']
            threshold = data.get('threshold', 0.5)
            
            results = inference_api.predict_batch(flux_data_list, threshold)
            summary = inference_api.create_summary_report(results)
            
            return jsonify({
                'results': results,
                'summary': summary
            })
            
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    @app.errorhandler(413)
    def too_large(e):
        """Handle file too large error."""
        return jsonify({'error': 'File too large. Maximum size is 16MB.'}), 413
    
    @app.errorhandler(404)
    def not_found(e):
        """Handle 404 errors."""
        return jsonify({'error': 'Endpoint not found'}), 404
    
    @app.errorhandler(500)
    def internal_error(e):
        """Handle internal server errors."""
        return jsonify({'error': 'Internal server error'}), 500
    
    return app


def run_server(host: str = '0.0.0.0', port: int = 5000, 
               model_path: str = None, model_type: str = 'cnn',
               debug: bool = False):
    """
    Run the Flask server.
    
    Args:
        host: Host address
        port: Port number
        model_path: Path to trained model
        model_type: Type of model
        debug: Enable debug mode
    """
    app = create_app(model_path=model_path, model_type=model_type)
    
    print(f"Starting ExoMind server on http://{host}:{port}")
    print("Available endpoints:")
    print("  GET  /              - Web interface")
    print("  GET  /health        - Health check")
    print("  GET  /model_info    - Model information")
    print("  POST /predict       - Predict from JSON")
    print("  POST /predict_csv   - Predict from CSV file")
    print("  POST /predict_batch - Batch prediction")
    
    app.run(host=host, port=port, debug=debug)


