"""
Training Script for ExoMind Transit Detector
============================================

Training script for the ExoMind transit detection model, adapted from AstroNet's training infrastructure.
"""

import os
import sys
import numpy as np
import tensorflow as tf
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, TensorBoard, LearningRateScheduler
import argparse
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from exomind.models.transit_detector import TransitDetector
from exomind.data.transit_dataset import TransitDataset
from exomind.utils.metrics import evaluate_model_performance
from exomind.utils.visualization import plot_training_history


def create_callbacks(checkpoint_dir: str, log_dir: str, 
                    use_early_stopping: bool = True,
                    patience: int = 10) -> list:
    """
    Create training callbacks.
    
    Args:
        checkpoint_dir: Directory to save model checkpoints
        log_dir: Directory for TensorBoard logs
        use_early_stopping: Whether to use early stopping
        patience: Patience for early stopping
        
    Returns:
        List of callbacks
    """
    os.makedirs(checkpoint_dir, exist_ok=True)
    os.makedirs(log_dir, exist_ok=True)
    
    callbacks = []
    
    # Model checkpoint
    checkpoint_path = os.path.join(checkpoint_dir, 'transit_detector_best.h5')
    checkpoint_callback = ModelCheckpoint(
        filepath=checkpoint_path,
        monitor='val_loss',
        save_best_only=True,
        save_weights_only=True,
        verbose=1
    )
    callbacks.append(checkpoint_callback)
    
    # TensorBoard
    tensorboard_callback = TensorBoard(
        log_dir=log_dir,
        histogram_freq=1,
        write_graph=True,
        update_freq='epoch'
    )
    callbacks.append(tensorboard_callback)
    
    # Early stopping
    if use_early_stopping:
        early_stopping = EarlyStopping(
            monitor='val_loss',
            patience=patience,
            restore_best_weights=True,
            verbose=1
        )
        callbacks.append(early_stopping)
    
    # Learning rate scheduler
    def lr_scheduler(epoch, lr):
        if epoch < 10:
            return lr
        elif epoch < 20:
            return lr * 0.5
        else:
            return lr * 0.1
    
    lr_callback = LearningRateScheduler(lr_scheduler, verbose=1)
    callbacks.append(lr_callback)
    
    return callbacks


def train_model(model_type: str = 'cnn',
                sequence_length: int = 1000,
                batch_size: int = 32,
                epochs: int = 50,
                learning_rate: float = 0.001,
                data_source: str = 'synthetic',
                use_class_weights: bool = True,
                checkpoint_dir: str = 'checkpoints',
                log_dir: str = 'logs'):
    """
    Train the transit detection model.
    
    Args:
        model_type: Type of model ('cnn', 'lstm', 'hybrid')
        sequence_length: Input sequence length
        batch_size: Batch size
        epochs: Number of epochs
        learning_rate: Learning rate
        data_source: Data source ('synthetic', 'kepler', 'tess')
        use_class_weights: Whether to use class weights
        checkpoint_dir: Directory for checkpoints
        log_dir: Directory for logs
    """
    print(f"Training ExoMind Transit Detector")
    print(f"Model type: {model_type}")
    print(f"Sequence length: {sequence_length}")
    print(f"Batch size: {batch_size}")
    print(f"Epochs: {epochs}")
    print(f"Learning rate: {learning_rate}")
    print(f"Data source: {data_source}")
    print(f"Use class weights: {use_class_weights}")
    print("-" * 50)
    
    # Create datasets
    print("Creating datasets...")
    train_dataset = TransitDataset(
        data_source=data_source,
        mode='train',
        window_size=sequence_length,
        batch_size=batch_size
    )
    
    val_dataset = TransitDataset(
        data_source=data_source,
        mode='validation',
        window_size=sequence_length,
        batch_size=batch_size
    )
    
    # Get dataset statistics
    train_stats = train_dataset.get_stats()
    val_stats = val_dataset.get_stats()
    
    print(f"Train dataset: {train_stats}")
    print(f"Validation dataset: {val_stats}")
    
    # Create model
    print("Creating model...")
    input_shape = (sequence_length, 1)
    model = TransitDetector(
        input_shape=input_shape,
        model_type=model_type,
        num_classes=2,
        use_class_weights=use_class_weights
    )
    
    # Compile model
    optimizer = Adam(learning_rate=learning_rate)
    model.compile(
        optimizer=optimizer,
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy', 'precision', 'recall']
    )
    
    print("Model summary:")
    model.get_model_summary()
    
    # Create callbacks
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    model_checkpoint_dir = os.path.join(checkpoint_dir, f"{model_type}_{timestamp}")
    model_log_dir = os.path.join(log_dir, f"{model_type}_{timestamp}")
    
    callbacks = create_callbacks(model_checkpoint_dir, model_log_dir)
    
    # Train model
    print("Starting training...")
    history = model.fit(
        train_dataset.get_dataset(),
        epochs=epochs,
        validation_data=val_dataset.get_dataset(),
        callbacks=callbacks,
        verbose=1
    )
    
    # Save final model
    final_model_path = os.path.join(model_checkpoint_dir, 'transit_detector_final.h5')
    model.save_weights(final_model_path)
    print(f"Final model saved to: {final_model_path}")
    
    # Evaluate model
    print("Evaluating model...")
    val_data = val_dataset.get_dataset()
    
    # Get predictions
    y_true_list = []
    y_pred_list = []
    y_prob_list = []
    
    for batch in val_data.take(10):  # Evaluate on subset for demo
        y_true_batch = batch['label'].numpy()
        y_pred_batch = model.predict(batch['flux'], verbose=0)
        
        y_true_list.extend(y_true_batch)
        y_pred_list.extend(np.argmax(y_pred_batch, axis=1))
        y_prob_list.extend(y_pred_batch[:, 1])  # Probability of positive class
    
    y_true = np.array(y_true_list)
    y_pred = np.array(y_pred_list)
    y_prob = np.array(y_prob_list)
    
    # Calculate metrics
    metrics = evaluate_model_performance(y_true, y_pred, y_prob)
    
    print("\nFinal Evaluation Metrics:")
    for key, value in metrics.items():
        print(f"  {key}: {value:.4f}")
    
    # Plot training history
    try:
        plot_training_history(history.history)
        plt.savefig(os.path.join(model_log_dir, 'training_history.png'))
        print(f"Training history plot saved to: {os.path.join(model_log_dir, 'training_history.png')}")
    except Exception as e:
        print(f"Could not save training history plot: {e}")
    
    return model, history, metrics


def main():
    """Main training function."""
    parser = argparse.ArgumentParser(description='Train ExoMind Transit Detector')
    
    parser.add_argument('--model_type', type=str, default='cnn',
                       choices=['cnn', 'lstm', 'hybrid'],
                       help='Type of model to train')
    parser.add_argument('--sequence_length', type=int, default=1000,
                       help='Input sequence length')
    parser.add_argument('--batch_size', type=int, default=32,
                       help='Batch size')
    parser.add_argument('--epochs', type=int, default=50,
                       help='Number of training epochs')
    parser.add_argument('--learning_rate', type=float, default=0.001,
                       help='Learning rate')
    parser.add_argument('--data_source', type=str, default='synthetic',
                       choices=['synthetic', 'kepler', 'tess'],
                       help='Data source')
    parser.add_argument('--no_class_weights', action='store_true',
                       help='Disable class weights')
    parser.add_argument('--checkpoint_dir', type=str, default='checkpoints',
                       help='Directory for model checkpoints')
    parser.add_argument('--log_dir', type=str, default='logs',
                       help='Directory for training logs')
    
    args = parser.parse_args()
    
    # Train model
    model, history, metrics = train_model(
        model_type=args.model_type,
        sequence_length=args.sequence_length,
        batch_size=args.batch_size,
        epochs=args.epochs,
        learning_rate=args.learning_rate,
        data_source=args.data_source,
        use_class_weights=not args.no_class_weights,
        checkpoint_dir=args.checkpoint_dir,
        log_dir=args.log_dir
    )
    
    print("\nTraining completed successfully!")
    print(f"Best model saved in: {args.checkpoint_dir}")


if __name__ == "__main__":
    main()


