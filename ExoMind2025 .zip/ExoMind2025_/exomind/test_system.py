"""
Test Script for ExoMind System
===============================

Simple test script to verify the ExoMind system is working correctly.
"""

import numpy as np
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from exomind.data.transit_dataset import TransitDataset
from exomind.models.transit_detector import TransitDetector
from exomind.api.inference import TransitInferenceAPI
from exomind.utils.preprocessing import prepare_for_model
from exomind.utils.metrics import compute_transit_metrics


def test_data_loading():
    """Test data loading functionality."""
    print("Testing data loading...")
    
    try:
        # Test synthetic dataset creation
        dataset = TransitDataset(
            data_source='synthetic',
            mode='train',
            window_size=1000,
            batch_size=8
        )
        
        stats = dataset.get_stats()
        print(f"✓ Dataset created successfully: {stats}")
        
        # Test dataset iteration
        data_iter = iter(dataset.get_dataset())
        batch = next(data_iter)
        
        print(f"✓ Batch shape: {batch['flux'].shape}")
        print(f"✓ Labels shape: {batch['label'].shape}")
        
        return True
        
    except Exception as e:
        print(f"✗ Data loading failed: {e}")
        return False


def test_model_creation():
    """Test model creation."""
    print("\nTesting model creation...")
    
    try:
        # Test CNN model
        cnn_model = TransitDetector(
            input_shape=(1000, 1),
            model_type='cnn'
        )
        print("✓ CNN model created successfully")
        
        # Test LSTM model
        lstm_model = TransitDetector(
            input_shape=(1000, 1),
            model_type='lstm'
        )
        print("✓ LSTM model created successfully")
        
        # Test model compilation
        cnn_model.compile(
            optimizer='adam',
            loss='sparse_categorical_crossentropy',
            metrics=['accuracy']
        )
        print("✓ Model compilation successful")
        
        return True
        
    except Exception as e:
        print(f"✗ Model creation failed: {e}")
        return False


def test_preprocessing():
    """Test preprocessing utilities."""
    print("\nTesting preprocessing...")
    
    try:
        # Generate synthetic flux data
        flux = np.random.normal(1.0, 0.001, 2000)
        
        # Add a synthetic transit
        transit_start = 500
        transit_end = 600
        flux[transit_start:transit_end] *= 0.99  # 1% dip
        
        # Test preprocessing
        processed_flux = prepare_for_model(flux, sequence_length=1000)
        
        print(f"✓ Preprocessing successful: {len(flux)} -> {len(processed_flux)}")
        
        return True
        
    except Exception as e:
        print(f"✗ Preprocessing failed: {e}")
        return False


def test_inference():
    """Test inference functionality."""
    print("\nTesting inference...")
    
    try:
        # Create inference API
        api = TransitInferenceAPI(model_type='cnn', sequence_length=1000)
        
        # Generate test data
        flux = np.random.normal(1.0, 0.001, 1000)
        
        # Test prediction (without loaded model)
        result = api.predict_single(flux)
        print(f"✓ Inference API created: {result}")
        
        return True
        
    except Exception as e:
        print(f"✗ Inference test failed: {e}")
        return False


def test_metrics():
    """Test metrics calculation."""
    print("\nTesting metrics...")
    
    try:
        # Generate test data
        y_true = np.array([0, 1, 0, 1, 0, 1, 0, 0, 1, 1])
        y_pred = np.array([0, 1, 0, 0, 0, 1, 0, 1, 1, 1])
        y_prob = np.array([0.1, 0.9, 0.2, 0.4, 0.1, 0.8, 0.2, 0.6, 0.7, 0.9])
        
        # Test metrics calculation
        metrics = compute_transit_metrics(y_true, y_pred, y_prob)
        
        print(f"✓ Metrics calculation successful:")
        for key, value in metrics.items():
            print(f"  {key}: {value:.4f}")
        
        return True
        
    except Exception as e:
        print(f"✗ Metrics test failed: {e}")
        return False


def run_all_tests():
    """Run all tests."""
    print("=" * 50)
    print("ExoMind System Tests")
    print("=" * 50)
    
    tests = [
        test_data_loading,
        test_model_creation,
        test_preprocessing,
        test_inference,
        test_metrics
    ]
    
    results = []
    for test in tests:
        results.append(test())
    
    print("\n" + "=" * 50)
    print("Test Results Summary")
    print("=" * 50)
    
    passed = sum(results)
    total = len(results)
    
    print(f"Passed: {passed}/{total}")
    
    if passed == total:
        print("✓ All tests passed! ExoMind system is working correctly.")
        return True
    else:
        print("✗ Some tests failed. Please check the errors above.")
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)


