"""
ExoMind Demo Script
===================

Demo script showing how to use ExoMind for transit detection.
"""

import numpy as np
import matplotlib.pyplot as plt
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from exomind.data.transit_dataset import TransitDataset
from exomind.models.transit_detector import TransitDetector
from exomind.utils.visualization import plot_lightcurve
from exomind.utils.preprocessing import prepare_for_model


def generate_demo_lightcurve(n_points: int = 1000, has_transit: bool = True):
    """Generate a demo lightcurve."""
    # Time array
    time = np.linspace(0, 30, n_points)  # 30 days
    
    # Base flux with noise
    flux = np.random.normal(1.0, 0.001, n_points)
    
    # Add stellar variability
    flux += 0.002 * np.sin(2 * np.pi * time / 20.0)
    
    # Add transit if requested
    if has_transit:
        transit_params = {
            'period': 10.0,
            't0': 15.0,
            'duration': 0.5,
            'depth': 0.005
        }
        
        # Add synthetic transit
        transit_times = [transit_params['t0']]
        while transit_times[-1] + transit_params['period'] < time[-1]:
            transit_times.append(transit_times[-1] + transit_params['period'])
        
        for transit_time in transit_times:
            transit_start = transit_time - transit_params['duration'] / 2
            transit_end = transit_time + transit_params['duration'] / 2
            
            in_transit = (time >= transit_start) & (time <= transit_end)
            flux[in_transit] *= (1 - transit_params['depth'])
    
    return time, flux


def demo_transit_detection():
    """Demo transit detection functionality."""
    print("ExoMind Transit Detection Demo")
    print("=" * 40)
    
    # Generate demo data
    print("1. Generating demo lightcurves...")
    
    # Lightcurve with transit
    time_with_transit, flux_with_transit = generate_demo_lightcurve(has_transit=True)
    
    # Lightcurve without transit
    time_no_transit, flux_no_transit = generate_demo_lightcurve(has_transit=False)
    
    # Plot lightcurves
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
    
    ax1.plot(time_with_transit, flux_with_transit, 'b-', alpha=0.7)
    ax1.set_title('Lightcurve with Transit')
    ax1.set_ylabel('Normalized Flux')
    ax1.grid(True, alpha=0.3)
    
    ax2.plot(time_no_transit, flux_no_transit, 'b-', alpha=0.7)
    ax2.set_title('Lightcurve without Transit')
    ax2.set_xlabel('Time (days)')
    ax2.set_ylabel('Normalized Flux')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('exomind_demo_lightcurves.png', dpi=150, bbox_inches='tight')
    print("✓ Lightcurves saved to 'exomind_demo_lightcurves.png'")
    
    # Create and train a simple model
    print("\n2. Creating and training model...")
    
    # Create dataset
    dataset = TransitDataset(
        data_source='synthetic',
        mode='train',
        window_size=1000,
        batch_size=16
    )
    
    # Create model
    model = TransitDetector(
        input_shape=(1000, 1),
        model_type='cnn'
    )
    
    model.compile(
        optimizer='adam',
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )
    
    print("✓ Model created and compiled")
    
    # Train for a few epochs
    print("\n3. Training model (demo - 5 epochs)...")
    
    history = model.fit(
        dataset.get_dataset(),
        epochs=5,
        steps_per_epoch=10,  # Small number for demo
        verbose=1
    )
    
    print("✓ Model training completed")
    
    # Test prediction
    print("\n4. Testing predictions...")
    
    # Prepare test data
    test_flux_with_transit = prepare_for_model(flux_with_transit, sequence_length=1000)
    test_flux_no_transit = prepare_for_model(flux_no_transit, sequence_length=1000)
    
    # Make predictions
    pred_with_transit = model.predict(np.expand_dims(test_flux_with_transit, axis=(0, -1)), verbose=0)
    pred_no_transit = model.predict(np.expand_dims(test_flux_no_transit, axis=(0, -1)), verbose=0)
    
    prob_with_transit = pred_with_transit[0][1]
    prob_no_transit = pred_no_transit[0][1]
    
    print(f"✓ Prediction for lightcurve with transit: {prob_with_transit:.3f}")
    print(f"✓ Prediction for lightcurve without transit: {prob_no_transit:.3f}")
    
    # Create prediction plot
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
    
    ax1.plot(time_with_transit, flux_with_transit, 'b-', alpha=0.7)
    ax1.set_title(f'Lightcurve with Transit (Predicted Probability: {prob_with_transit:.3f})')
    ax1.set_ylabel('Normalized Flux')
    ax1.grid(True, alpha=0.3)
    
    ax2.plot(time_no_transit, flux_no_transit, 'b-', alpha=0.7)
    ax2.set_title(f'Lightcurve without Transit (Predicted Probability: {prob_no_transit:.3f})')
    ax2.set_xlabel('Time (days)')
    ax2.set_ylabel('Normalized Flux')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('exomind_demo_predictions.png', dpi=150, bbox_inches='tight')
    print("✓ Prediction results saved to 'exomind_demo_predictions.png'")
    
    print("\n" + "=" * 40)
    print("Demo completed successfully!")
    print("=" * 40)


if __name__ == "__main__":
    demo_transit_detection()


