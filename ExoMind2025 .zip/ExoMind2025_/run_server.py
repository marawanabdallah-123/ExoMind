#!/usr/bin/env python3
"""
ExoMind Server Entry Point
==========================

Entry point script for running the ExoMind Flask server.
This script handles the import path issues and provides a clean way to start the server.

Usage:
    python run_server.py [--model-path MODEL_PATH] [--port PORT] [--host HOST] [--debug]

Examples:
    python run_server.py
    python run_server.py --model-path models/transit_detector.h5 --port 8080
    python run_server.py --debug
"""

import argparse
import sys
import os

# Add the current directory to Python path to resolve imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from exomind.api.server import create_app, run_server


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description='Run the ExoMind transit detection server',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    parser.add_argument(
        '--model-path', 
        type=str, 
        default=None,
        help='Path to the trained model file (default: None - will use default model)'
    )
    
    parser.add_argument(
        '--model-type',
        type=str,
        choices=['cnn', 'lstm', 'hybrid'],
        default='cnn',
        help='Type of model to use (default: cnn)'
    )
    
    parser.add_argument(
        '--host',
        type=str,
        default='0.0.0.0',
        help='Host address to bind to (default: 0.0.0.0)'
    )
    
    parser.add_argument(
        '--port',
        type=int,
        default=5000,
        help='Port number to bind to (default: 5000)'
    )
    
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug mode'
    )
    
    args = parser.parse_args()
    
    print("ExoMind Transit Detection Server")
    print("=" * 40)
    print(f"Model path: {args.model_path or 'Default model'}")
    print(f"Model type: {args.model_type}")
    print(f"Host: {args.host}")
    print(f"Port: {args.port}")
    print(f"Debug: {args.debug}")
    print("=" * 40)
    
    try:
        run_server(
            host=args.host,
            port=args.port,
            model_path=args.model_path,
            model_type=args.model_type,
            debug=args.debug
        )
    except KeyboardInterrupt:
        print("\nServer stopped by user")
        sys.exit(0)
    except Exception as e:
        print(f"Error starting server: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
