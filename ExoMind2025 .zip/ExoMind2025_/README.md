# ExoMind - AI-Powered Exoplanet Transit Detection

ExoMind is an advanced machine learning system for detecting exoplanet transits in lightcurve data. Built with TensorFlow/Keras, it provides both a web API and Python interface for transit detection.

## Features

- 🚀 **Multiple Model Architectures**: CNN, LSTM, and Hybrid models
- 🌐 **Web Interface**: User-friendly web UI for lightcurve analysis
- 🔧 **REST API**: Programmatic access via HTTP endpoints
- 📊 **Comprehensive Metrics**: Detailed performance analysis
- 🧪 **Built-in Testing**: Unit tests and system validation
- 📦 **Easy Setup**: Simple installation and configuration

## Quick Start

### 1. Installation

```bash
# Clone the repository
git clone https://github.com/your-repo/exomind.git
cd exomind

# Install dependencies
pip install -r requirements.txt

# Download pre-trained models (optional)
python download_models.py --model cnn
```

### 2. Start the Server

```bash
# Start with default settings
python run_server.py

# Or with specific model
python run_server.py --model-path models/transit_detector_cnn.h5 --port 8080
```

### 3. Use the Web Interface

Open your browser and go to `http://localhost:5000`

Upload a CSV file with your lightcurve data and get instant transit detection results!

## API Usage

### Python API

```python
from exomind.api.inference import TransitInferenceAPI
import numpy as np

# Initialize API
api = TransitInferenceAPI(model_path='models/transit_detector_cnn.h5')

# Analyze lightcurve
flux_data = np.random.normal(1.0, 0.001, 1000)
result = api.predict_single(flux_data)

print(f"Transit detected: {result['has_transit']}")
print(f"Confidence: {result['confidence']:.3f}")
```

### REST API

```bash
# Health check
curl http://localhost:5000/health

# Predict from JSON
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{"flux": [1.0, 1.01, 0.99, 1.02, 0.98]}'

# Predict from CSV file
curl -X POST -F "file=@lightcurve.csv" http://localhost:5000/predict_csv
```

## Data Format

### CSV Format

Your lightcurve CSV should have columns for time and flux:

```csv
time,flux
0.0,1.000
0.1,1.001
0.2,0.999
0.3,1.002
...
```

### JSON Format

For API calls, use this JSON structure:

```json
{
  "flux": [1.0, 1.01, 0.99, 1.02, 0.98],
  "threshold": 0.5
}
```

## Model Types

| Model | Accuracy | Speed | Memory | Best For |
|-------|----------|-------|--------|----------|
| CNN   | ~85%     | Fast  | Low    | General use |
| LSTM  | ~88%     | Medium| Medium | Long sequences |
| Hybrid| ~92%     | Slow  | High   | Best accuracy |

## Testing

Run the comprehensive test suite:

```bash
# Run all tests
python run_tests.py

# Run specific test types
python run_tests.py --imports-only
python run_tests.py --system-only
python run_tests.py --unit-only

# Run with pytest (if installed)
python -m pytest tests/ -v
```

## Development

### Setup Development Environment

```bash
# Install development dependencies
pip install -r requirements-dev.txt

# Run linting
black exomind/
flake8 exomind/

# Run type checking
mypy exomind/
```

### Project Structure

```
ExoMind2025/
├── exomind/                 # Main package
│   ├── api/                # Web API and inference
│   ├── data/               # Data loading and processing
│   ├── models/             # Model architectures
│   └── utils/              # Utilities and helpers
├── tests/                  # Unit tests
├── models/                 # Pre-trained models
├── requirements.txt        # Dependencies
├── run_server.py          # Server entry point
└── run_tests.py           # Test runner
```

## Configuration

### Environment Variables

```bash
# Model configuration
export EXOMIND_MODEL_PATH=models/transit_detector_cnn.h5
export EXOMIND_MODEL_TYPE=cnn

# Server configuration
export EXOMIND_HOST=0.0.0.0
export EXOMIND_PORT=5000
export EXOMIND_DEBUG=false
```

### Command Line Options

```bash
python run_server.py --help

Options:
  --model-path PATH    Path to trained model file
  --model-type TYPE    Model type (cnn/lstm/hybrid)
  --host HOST         Host address (default: 0.0.0.0)
  --port PORT         Port number (default: 5000)
  --debug             Enable debug mode
```

## Troubleshooting

### Common Issues

1. **Import Errors**
   ```bash
   # Test imports
   python test_imports.py
   ```

2. **Model Loading Issues**
   ```bash
   # Check model info
   curl http://localhost:5000/model_info
   ```

3. **Memory Issues**
   - Use CNN model instead of hybrid
   - Reduce sequence length
   - Use smaller batch sizes

4. **Performance Issues**
   - Enable GPU acceleration
   - Use CNN model for fastest inference
   - Optimize data preprocessing

### Getting Help

1. Check the logs for error messages
2. Run the test suite: `python run_tests.py`
3. Verify model setup: See `MODEL_SETUP.md`
4. Check API status: Visit `/health` endpoint

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Run the test suite
6. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Citation

If you use ExoMind in your research, please cite:

```bibtex
@software{exomind2025,
  title={ExoMind: AI-Powered Exoplanet Transit Detection},
  author={Your Name},
  year={2025},
  url={https://github.com/your-repo/exomind}
}
```

## Acknowledgments

- Built with TensorFlow/Keras
- Inspired by AstroNet architecture
- Uses Kepler and TESS mission data
- Thanks to the exoplanet research community

---

**Ready to detect exoplanets?** Start the server and upload your first lightcurve! 🚀
